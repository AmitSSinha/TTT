(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const KEY = 'exampro-admin-mentor-state-v1';
  const toast = $('#adminToast');
  let toastTimer;
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
  };
  const initials = name => name.split(/\s+/).map(part => part[0]).join('').slice(0,2).toUpperCase();
  const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const today = '2026-07-27';

  const seed = {
    classes: [
      {id:'CL-1042',title:'Time & Work: Advanced Problems',subject:'Quantitative Aptitude',mentor:'Rohit Sharma',cohort:'SSC CGL Champions A',date:today,time:'15:00',duration:75,registrations:1240,readiness:96,status:'Upcoming'},
      {id:'CL-1043',title:'Error Spotting Masterclass',subject:'English Language',mentor:'Neha Verma',cohort:'SSC CGL Champions B',date:today,time:'16:30',duration:60,registrations:980,readiness:88,status:'Needs setup'},
      {id:'CL-1044',title:'Seating Arrangement Live Drill',subject:'Reasoning',mentor:'Aman Singh',cohort:'Bank PO Sprint 2026',date:today,time:'11:30',duration:90,registrations:1468,readiness:100,status:'Live'},
      {id:'CL-1045',title:'Current Affairs: July Week 4',subject:'General Awareness',mentor:'Priya Nair',cohort:'SSC CHSL Foundation',date:today,time:'18:00',duration:60,registrations:860,readiness:93,status:'Upcoming'},
      {id:'CL-1038',title:'Ratio & Proportion Revision',subject:'Quantitative Aptitude',mentor:'Rohit Sharma',cohort:'SSC CGL Champions A',date:'2026-07-26',time:'14:00',duration:60,registrations:1104,readiness:100,status:'Completed'},
      {id:'CL-1046',title:'Coding-Decoding Practice',subject:'Reasoning',mentor:'Aman Singh',cohort:'RRB NTPC Accelerator',date:'2026-07-28',time:'10:00',duration:60,registrations:720,readiness:76,status:'Needs setup'},
      {id:'CL-1047',title:'Vocabulary Through Context',subject:'English Language',mentor:'Neha Verma',cohort:'SSC CHSL Foundation',date:'2026-07-28',time:'17:00',duration:55,registrations:805,readiness:91,status:'Upcoming'}
    ],
    cohorts: [
      {id:'CO-101',name:'SSC CGL Champions A',exam:'SSC CGL',mentor:'Rohit Sharma',learners:486,progress:72,attendance:91,risk:18,health:'Strong',schedule:'Mon–Sat · 3 PM'},
      {id:'CO-102',name:'SSC CGL Champions B',exam:'SSC CGL',mentor:'Neha Verma',learners:438,progress:64,attendance:86,risk:31,health:'Watch',schedule:'Mon–Sat · 5 PM'},
      {id:'CO-103',name:'Bank PO Sprint 2026',exam:'Bank PO',mentor:'Aman Singh',learners:522,progress:78,attendance:93,risk:14,health:'Strong',schedule:'Daily · 11:30 AM'},
      {id:'CO-104',name:'SSC CHSL Foundation',exam:'SSC CHSL',mentor:'Priya Nair',learners:364,progress:51,attendance:74,risk:46,health:'At risk',schedule:'Mon–Fri · 6 PM'},
      {id:'CO-105',name:'RRB NTPC Accelerator',exam:'RRB NTPC',mentor:'Aman Singh',learners:318,progress:59,attendance:81,risk:27,health:'Watch',schedule:'Tue–Sun · 10 AM'},
      {id:'CO-106',name:'CGL Weekend Revision',exam:'SSC CGL',mentor:'Rohit Sharma',learners:276,progress:83,attendance:89,risk:9,health:'Strong',schedule:'Sat–Sun · 9 AM'}
    ],
    assignments: [
      {id:'AS-209',title:'Time & Work Practice Set 04',cohort:'SSC CGL Champions A',subject:'Quantitative Aptitude',due:'Today · 8 PM',submitted:376,total:486,graded:210,status:'Grading'},
      {id:'AS-210',title:'Error Spotting Worksheet',cohort:'SSC CGL Champions B',subject:'English Language',due:'Tomorrow · 6 PM',submitted:314,total:438,graded:0,status:'Open'},
      {id:'AS-211',title:'Seating Arrangement Drill',cohort:'Bank PO Sprint 2026',subject:'Reasoning',due:'Today · 10 PM',submitted:462,total:522,graded:348,status:'Grading'},
      {id:'AS-212',title:'July Current Affairs Quiz',cohort:'SSC CHSL Foundation',subject:'General Awareness',due:'29 Jul · 9 PM',submitted:198,total:364,graded:0,status:'Open'},
      {id:'AS-207',title:'Percentage Mixed Problems',cohort:'SSC CGL Champions A',subject:'Quantitative Aptitude',due:'Closed 25 Jul',submitted:452,total:486,graded:452,status:'Completed'},
      {id:'AS-213',title:'Coding-Decoding Mini Test',cohort:'RRB NTPC Accelerator',subject:'Reasoning',due:'Draft',submitted:0,total:318,graded:0,status:'Draft'}
    ],
    attendance: [
      {id:'AT-41',session:'Seating Arrangement Live Drill',cohort:'Bank PO Sprint 2026',mentor:'Aman Singh',date:'27 Jul · 11:30 AM',present:468,late:24,absent:30,total:522},
      {id:'AT-40',session:'Time & Work: Advanced Problems',cohort:'SSC CGL Champions A',mentor:'Rohit Sharma',date:'27 Jul · 3:00 PM',present:421,late:18,absent:47,total:486},
      {id:'AT-39',session:'Error Spotting Masterclass',cohort:'SSC CGL Champions B',mentor:'Neha Verma',date:'26 Jul · 5:00 PM',present:371,late:16,absent:51,total:438},
      {id:'AT-38',session:'Current Affairs: July Week 4',cohort:'SSC CHSL Foundation',mentor:'Priya Nair',date:'26 Jul · 6:00 PM',present:259,late:11,absent:94,total:364},
      {id:'AT-37',session:'Coding-Decoding Practice',cohort:'RRB NTPC Accelerator',mentor:'Aman Singh',date:'25 Jul · 10:00 AM',present:263,late:19,absent:36,total:318}
    ],
    doubts: [
      {id:'DQ-810',title:'Why is work efficiency inversely proportional to time?',learner:'Shreya Patel',cohort:'SSC CGL Champions A',subject:'Quantitative Aptitude',priority:'High',status:'Open',age:'4h 18m',mentor:'Unassigned'},
      {id:'DQ-811',title:'Difference between affect and effect in this sentence',learner:'Rahul Mehta',cohort:'SSC CGL Champions B',subject:'English Language',priority:'Medium',status:'Assigned',age:'2h 06m',mentor:'Neha Verma'},
      {id:'DQ-812',title:'Circular seating: when should direction reverse?',learner:'Ayesha Khan',cohort:'Bank PO Sprint 2026',subject:'Reasoning',priority:'High',status:'Escalated',age:'3h 42m',mentor:'Aman Singh'},
      {id:'DQ-813',title:'Which source should we use for current appointments?',learner:'Vikas Yadav',cohort:'SSC CHSL Foundation',subject:'General Awareness',priority:'Normal',status:'Open',age:'58m',mentor:'Unassigned'},
      {id:'DQ-814',title:'Shortcut for successive percentage change',learner:'Manish Gupta',cohort:'RRB NTPC Accelerator',subject:'Quantitative Aptitude',priority:'Medium',status:'Assigned',age:'1h 22m',mentor:'Rohit Sharma'},
      {id:'DQ-815',title:'Is “each of the players are” grammatically correct?',learner:'Nisha Singh',cohort:'SSC CGL Champions B',subject:'English Language',priority:'Normal',status:'Resolved',age:'Resolved 12m ago',mentor:'Neha Verma'}
    ],
    mentors: [
      {name:'Rohit Sharma',subject:'Quantitative Aptitude',open:8,csat:4.81,classes:42,scoreLift:15.4},
      {name:'Neha Verma',subject:'English Language',open:6,csat:4.76,classes:38,scoreLift:13.8},
      {name:'Aman Singh',subject:'Reasoning',open:11,csat:4.72,classes:45,scoreLift:14.6},
      {name:'Priya Nair',subject:'General Awareness',open:5,csat:4.68,classes:31,scoreLift:9.7},
      {name:'Kavita Rao',subject:'English Language',open:9,csat:4.62,classes:29,scoreLift:11.2}
    ],
    preferences:{reminder24:true,reminder1:true,gradingDigest:false},
    audit:[]
  };

  let state;
  try { state = {...seed, ...JSON.parse(localStorage.getItem(KEY) || '{}')}; } catch { state = structuredClone(seed); }
  ['classes','cohorts','assignments','attendance','doubts','mentors','audit'].forEach(key => { if (!Array.isArray(state[key])) state[key] = structuredClone(seed[key]); });
  state.preferences = {...seed.preferences, ...(state.preferences || {})};
  const persist = () => localStorage.setItem(KEY, JSON.stringify(state));

  const modal = $('#mentorModal');
  const modalBody = $('#mentorModalBody');
  const openModal = html => { modalBody.innerHTML = html; modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); };
  const closeModal = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); };
  $('#closeMentorModal')?.addEventListener('click', closeModal);
  modal?.addEventListener('click', event => { if (event.target === modal) closeModal(); });

  const drawer = $('#mentorDrawer');
  const openDrawer = ({eyebrow='DETAILS',title,copy='',body}) => {
    $('#drawerEyebrow').textContent = eyebrow;
    $('#drawerTitle').textContent = title;
    $('#drawerCopy').textContent = copy;
    $('#mentorDrawerBody').innerHTML = `<div class="mp-drawer-body">${body}</div>`;
    drawer.classList.add('open'); drawer.setAttribute('aria-hidden','false');
  };
  const closeDrawer = () => { drawer.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); };
  $('#closeMentorDrawer')?.addEventListener('click', closeDrawer);
  drawer?.addEventListener('click', event => { if (event.target === drawer) closeDrawer(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') { closeModal(); closeDrawer(); } });

  function setTab(tab) {
    $$('.mp-tabbar [data-tab]').forEach(button => button.classList.toggle('active', button.dataset.tab === tab));
    $$('.mp-panel').forEach(panel => panel.classList.toggle('active', panel.dataset.panel === tab));
    history.replaceState(null,'',`#${tab}`);
  }
  $('.mp-tabbar')?.addEventListener('click', event => { const button = event.target.closest('[data-tab]'); if (button) setTab(button.dataset.tab); });
  $$('[data-open-tab]').forEach(button => button.addEventListener('click', () => setTab(button.dataset.openTab)));
  const initialTab = location.hash.replace('#','');
  if (['overview','classes','cohorts','assignments','attendance','doubts','analytics'].includes(initialTab)) setTab(initialTab);

  function renderSummary() {
    $('#classesToday').textContent = state.classes.filter(item => item.date === today).length;
    $('#activeMentors').textContent = Math.max(176, state.mentors.length);
    const totalPresent = state.attendance.reduce((sum,item)=>sum+item.present+item.late,0);
    const total = state.attendance.reduce((sum,item)=>sum+item.total,0);
    $('#attendanceToday').textContent = `${(totalPresent/total*100).toFixed(1)}%`;
    $('#assignmentsDue').textContent = state.assignments.filter(item => ['Open','Grading'].includes(item.status)).length;
    $('#openDoubts').textContent = state.doubts.filter(item => item.status !== 'Resolved').length;
    $('#doubtTabCount').textContent = state.doubts.filter(item => item.status !== 'Resolved').length;
    $('#assignmentTabCount').textContent = state.assignments.filter(item => item.status !== 'Completed').length;
    $('#cohortTabCount').textContent = state.cohorts.length;
    $('#classTabCount').textContent = state.classes.filter(item => item.date === today).length;
  }

  function renderOverview() {
    const order = [...state.classes].filter(item => item.date === today).sort((a,b)=>a.time.localeCompare(b.time)).slice(0,5);
    $('#overviewSchedule').innerHTML = order.map(item => `<article class="mp-timeline-item"><time class="mp-timeline-time">${escapeHtml(item.time)}</time><i class="mp-timeline-dot ${item.status === 'Live' ? 'live' : item.status === 'Completed' ? 'review' : ''}"></i><div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.mentor)} · ${escapeHtml(item.cohort)} · ${item.duration} min</p></div><button class="${item.status === 'Live' ? 'primary' : ''}" data-class-open="${item.id}">${item.status === 'Live' ? 'Join studio' : 'Manage'}</button></article>`).join('') || '<p class="empty-state">No classes scheduled today.</p>';
    $('#overviewCohorts').innerHTML = state.cohorts.slice(0,5).map(item => `<article class="mp-health-row"><div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.mentor)} · ${item.learners} learners</p></div><strong>${item.progress}%</strong><i class="mp-health-meter ${item.health === 'At risk' ? 'danger' : item.health === 'Watch' ? 'warn' : ''}"><b style="width:${item.progress}%"></b></i><span>${item.attendance}% attend.</span><span class="mp-status ${item.health === 'Strong' ? 'strong' : item.health === 'Watch' ? 'watch' : 'risk'}">${item.health}</span></article>`).join('');
  }

  function renderClasses() {
    const term = $('#classSearch')?.value.trim().toLowerCase() || '';
    const status = $('#classStatusFilter')?.value || 'all';
    const subject = $('#classSubjectFilter')?.value || 'all';
    const sort = $('#classSort')?.value || 'time';
    let list = state.classes.filter(item => (!term || [item.title,item.mentor,item.subject,item.cohort,item.id].some(value => value.toLowerCase().includes(term))) && (status === 'all' || item.status === status) && (subject === 'all' || item.subject === subject));
    list.sort((a,b)=> sort === 'registrations' ? b.registrations-a.registrations : sort === 'readiness' ? b.readiness-a.readiness : `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
    $('#classTableMeta').textContent = `Showing ${list.length} of ${state.classes.length} classes`;
    $('#classTableBody').innerHTML = list.map(item => `<tr><td><div class="mp-entity"><span>▣</span><div><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.subject)} · ${item.id}</small></div></div></td><td>${escapeHtml(item.mentor)}</td><td>${escapeHtml(item.cohort)}</td><td><strong>${item.date === today ? 'Today' : escapeHtml(item.date)}</strong><br><small>${escapeHtml(item.time)} · ${item.duration} min</small></td><td>${item.registrations.toLocaleString('en-IN')}</td><td><div class="mp-ready"><i><b style="width:${item.readiness}%"></b></i><span>${item.readiness}%</span></div></td><td><span class="mp-status ${item.status.toLowerCase().replace(/\s+/g,'-').replace('needs-setup','setup')}">${escapeHtml(item.status)}</span></td><td><div class="mp-row-actions"><button data-class-open="${item.id}">Manage</button><button data-class-more="${item.id}">•••</button></div></td></tr>`).join('') || '<tr><td colspan="8">No classes match the selected filters.</td></tr>';
  }

  function renderCohorts() {
    const term = $('#cohortSearch')?.value.trim().toLowerCase() || '';
    const exam = $('#cohortExamFilter')?.value || 'all';
    const health = $('#cohortHealthFilter')?.value || 'all';
    const list = state.cohorts.filter(item => (!term || [item.name,item.mentor,item.exam].some(value => value.toLowerCase().includes(term))) && (exam === 'all' || item.exam === exam) && (health === 'all' || item.health === health));
    $('#cohortGrid').innerHTML = list.map(item => `<article class="mp-cohort-card" data-cohort-open="${item.id}"><header><div><span class="eyebrow">${escapeHtml(item.exam)}</span><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.schedule)}</p></div><span class="mp-status ${item.health === 'Strong' ? 'strong' : item.health === 'Watch' ? 'watch' : 'risk'}">${item.health}</span></header><div class="mp-cohort-mentor"><span>${initials(item.mentor)}</span><div><strong>${escapeHtml(item.mentor)}</strong><small>Lead mentor</small></div></div><div class="mp-cohort-stats"><div><strong>${item.learners}</strong><small>Learners</small></div><div><strong>${item.attendance}%</strong><small>Attendance</small></div><div><strong>${item.risk}</strong><small>At risk</small></div></div><div class="mp-cohort-progress"><div><span>Syllabus progress</span><strong>${item.progress}%</strong></div><i><b style="width:${item.progress}%"></b></i></div></article>`).join('') || '<p>No cohorts match the selected filters.</p>';
  }

  function renderAssignments() {
    const filter = $('#assignmentStatusFilter')?.value || 'all';
    const list = state.assignments.filter(item => filter === 'all' || item.status === filter);
    $('#assignmentList').innerHTML = list.map(item => { const completion = Math.round(item.submitted/item.total*100 || 0); const grade = Math.round(item.graded/item.total*100 || 0); return `<article class="mp-assignment-item"><div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.subject)} · ${escapeHtml(item.cohort)}</p></div><div><small>Submitted</small><strong>${item.submitted}/${item.total}</strong></div><div><small>Completion</small><strong>${completion}%</strong></div><div><small>Graded</small><strong>${grade}%</strong></div><span class="mp-status ${item.status.toLowerCase()}">${item.status}</span><button data-assignment-open="${item.id}">Manage</button></article>`; }).join('') || '<p>No assignments found.</p>';
  }

  function renderAttendance() {
    const cohort = $('#attendanceCohortFilter')?.value || 'all';
    const list = state.attendance.filter(item => cohort === 'all' || item.cohort === cohort);
    $('#attendanceTableBody').innerHTML = list.map(item => { const rate = Math.round((item.present+item.late)/item.total*100); return `<tr><td><strong>${escapeHtml(item.session)}</strong></td><td>${escapeHtml(item.cohort)}</td><td>${escapeHtml(item.mentor)}</td><td>${escapeHtml(item.date)}</td><td>${item.present}</td><td>${item.late}</td><td>${item.absent}</td><td><div class="mp-ready"><i><b style="width:${rate}%"></b></i><span>${rate}%</span></div></td><td><div class="mp-row-actions"><button data-attendance-open="${item.id}">Review</button></div></td></tr>`; }).join('');
    $('#attendanceMeta').textContent = `${list.length} recent sessions`;
    const days = [{d:'Mon',v:82},{d:'Tue',v:86},{d:'Wed',v:84},{d:'Thu',v:89},{d:'Fri',v:87},{d:'Sat',v:91},{d:'Sun',v:76}];
    $('#attendanceChart').innerHTML = days.map(item => `<div><strong>${item.v}%</strong><i style="height:${item.v}%"></i><span>${item.d}</span></div>`).join('');
    const followups = [{name:'Arjun Kumar',cohort:'SSC CHSL Foundation',missed:4},{name:'Meena Devi',cohort:'SSC CGL Champions B',missed:3},{name:'Kabir Khan',cohort:'RRB NTPC Accelerator',missed:3}];
    $('#followupList').innerHTML = followups.map(item => `<article class="mp-followup"><span>${initials(item.name)}</span><div><strong>${item.name}</strong><small>${item.cohort}</small></div><b>${item.missed} missed</b></article>`).join('');
  }

  function renderDoubts() {
    const priority = $('#doubtPriorityFilter')?.value || 'all';
    const status = $('#doubtStatusFilter')?.value || 'all';
    const list = state.doubts.filter(item => (priority === 'all' || item.priority === priority) && (status === 'all' || item.status === status));
    $('#doubtMeta').textContent = `${state.doubts.filter(item=>item.status!=='Resolved').length} open doubts across active cohorts.`;
    $('#doubtList').innerHTML = list.map(item => `<article class="mp-doubt-item"><span class="mp-priority ${item.priority.toLowerCase()}">${item.priority[0]}</span><div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.learner)} · ${escapeHtml(item.cohort)} · ${escapeHtml(item.subject)}</p></div><div><small>${escapeHtml(item.mentor)}</small><strong>${escapeHtml(item.age)}</strong></div><span class="mp-status ${item.status.toLowerCase()}">${item.status}</span><button data-doubt-open="${item.id}">${item.status === 'Resolved' ? 'View' : 'Respond'}</button></article>`).join('') || '<p>No doubts match the selected filters.</p>';
    $('#mentorLoad').innerHTML = state.mentors.slice().sort((a,b)=>b.open-a.open).map(item => `<article class="mp-load-row"><span>${initials(item.name)}</span><div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.subject)}</small></div><b>${item.open} open</b></article>`).join('');
  }

  function renderAnalytics() {
    const cohorts = state.cohorts.slice(0,6);
    $('#impactChart').innerHTML = cohorts.map(item => { const lift = Math.max(6, Math.round((item.progress + item.attendance)/12)); return `<div class="mp-impact-col"><i style="height:${Math.min(92,lift*5)}%" data-value="+${lift}.${item.id.slice(-1)}"></i><strong>${escapeHtml(item.name.replace('SSC ','').replace(' Champions',''))}</strong><span>${escapeHtml(item.exam)}</span></div>`; }).join('');
    $('#mentorRanking').innerHTML = state.mentors.slice().sort((a,b)=>b.csat-a.csat).map((item,index)=>`<article class="mp-rank-row"><strong>${index+1}</strong><span>${initials(item.name)}</span><div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.subject)} · ${item.classes} classes</p></div><b>${item.csat.toFixed(2)} ★</b></article>`).join('');
    const subjects = [
      {name:'Quantitative Aptitude',cohorts:3,attendance:89,completion:78,accuracy:71,lift:'+14.8',health:'Strong'},
      {name:'Reasoning',cohorts:2,attendance:92,completion:84,accuracy:76,lift:'+13.6',health:'Strong'},
      {name:'English Language',cohorts:3,attendance:84,completion:69,accuracy:68,lift:'+11.4',health:'Watch'},
      {name:'General Awareness',cohorts:2,attendance:76,completion:61,accuracy:59,lift:'+8.2',health:'At risk'}
    ];
    $('#subjectAnalyticsBody').innerHTML = subjects.map(item=>`<tr><td><strong>${item.name}</strong></td><td>${item.cohorts}</td><td>${item.attendance}%</td><td>${item.completion}%</td><td>${item.accuracy}%</td><td><strong class="good">${item.lift}</strong></td><td><span class="mp-status ${item.health==='Strong'?'strong':item.health==='Watch'?'watch':'risk'}">${item.health}</span></td></tr>`).join('');
  }

  function renderAll() { renderSummary(); renderOverview(); renderClasses(); renderCohorts(); renderAssignments(); renderAttendance(); renderDoubts(); renderAnalytics(); }

  function classDetails(id) {
    const item = state.classes.find(row => row.id === id); if (!item) return;
    openDrawer({eyebrow:'CLASS OPERATIONS',title:item.title,copy:`${item.id} · ${item.subject}`,body:`<div class="mp-detail-grid"><div><small>Mentor</small><strong>${escapeHtml(item.mentor)}</strong></div><div><small>Cohort</small><strong>${escapeHtml(item.cohort)}</strong></div><div><small>Schedule</small><strong>${item.date === today ? 'Today' : item.date} · ${item.time}</strong></div><div><small>Duration</small><strong>${item.duration} minutes</strong></div><div><small>Registrations</small><strong>${item.registrations.toLocaleString('en-IN')}</strong></div><div><small>Readiness</small><strong>${item.readiness}%</strong></div></div><section class="mp-drawer-section"><h3>Readiness checklist</h3><div class="mp-check-row"><span>Mentor availability</span><strong class="good">Confirmed</strong></div><div class="mp-check-row"><span>Presentation deck</span><strong class="good">Uploaded</strong></div><div class="mp-check-row"><span>Practice questions</span><strong class="${item.readiness<90?'warn':'good'}">${item.readiness<90?'Needs review':'Ready'}</strong></div><div class="mp-check-row"><span>Learner notification</span><strong class="good">Sent</strong></div></section><div class="mp-modal-actions"><button data-class-action="notify" data-id="${item.id}">Notify learners</button><button data-class-action="edit" data-id="${item.id}">Edit class</button><button class="primary" data-class-action="studio" data-id="${item.id}">${item.status==='Live'?'Join studio':'Open studio'}</button></div>`});
  }

  function cohortDetails(id) {
    const item = state.cohorts.find(row => row.id === id); if (!item) return;
    const names = ['Aarav Singh','Diya Sharma','Rehan Khan','Sakshi Patel','Vivek Kumar','Pooja Verma'];
    openDrawer({eyebrow:'COHORT OPERATIONS',title:item.name,copy:`${item.exam} · ${item.learners} learners`,body:`<div class="mp-detail-grid"><div><small>Lead mentor</small><strong>${escapeHtml(item.mentor)}</strong></div><div><small>Schedule</small><strong>${escapeHtml(item.schedule)}</strong></div><div><small>Syllabus progress</small><strong>${item.progress}%</strong></div><div><small>Attendance</small><strong>${item.attendance}%</strong></div><div><small>Learners at risk</small><strong>${item.risk}</strong></div><div><small>Health</small><strong>${item.health}</strong></div></div><section class="mp-drawer-section"><h3>Learner sample</h3><div class="mp-roster-list">${names.map((name,index)=>`<article class="mp-roster-row"><span>${initials(name)}</span><div><strong>${name}</strong><small>${index<2?'Strong progress':index<4?'On track':'Needs attention'}</small></div><b>${Math.max(48,item.progress+8-index*5)}%</b><b>${Math.max(62,item.attendance-index*4)}% attend.</b></article>`).join('')}</div></section><div class="mp-modal-actions"><button data-cohort-action="message" data-id="${item.id}">Message cohort</button><button data-cohort-action="roster" data-id="${item.id}">Export roster</button><button class="primary" data-cohort-action="edit" data-id="${item.id}">Edit cohort</button></div>`});
  }

  function assignmentDetails(id) {
    const item = state.assignments.find(row=>row.id===id); if (!item) return;
    const completion = Math.round(item.submitted/item.total*100 || 0); const grade = Math.round(item.graded/item.total*100 || 0);
    openDrawer({eyebrow:'ASSIGNMENT OPERATIONS',title:item.title,copy:`${item.id} · ${item.cohort}`,body:`<div class="mp-detail-grid"><div><small>Subject</small><strong>${item.subject}</strong></div><div><small>Deadline</small><strong>${item.due}</strong></div><div><small>Submitted</small><strong>${item.submitted}/${item.total} (${completion}%)</strong></div><div><small>Graded</small><strong>${item.graded}/${item.total} (${grade}%)</strong></div></div><section class="mp-drawer-section"><h3>Submission progress</h3><div class="mp-progress-row"><span>Received</span><strong>${completion}%</strong><i><b style="width:${completion}%"></b></i></div><div class="mp-progress-row"><span>Graded</span><strong>${grade}%</strong><i><b style="width:${grade}%"></b></i></div></section><div class="mp-modal-actions"><button data-assignment-action="remind" data-id="${item.id}">Send reminder</button><button data-assignment-action="export" data-id="${item.id}">Export submissions</button><button class="primary" data-assignment-action="grade" data-id="${item.id}">Open grading</button></div>`});
  }

  function doubtDetails(id) {
    const item = state.doubts.find(row=>row.id===id); if (!item) return;
    openDrawer({eyebrow:'LEARNER DOUBT',title:item.title,copy:`${item.id} · ${item.subject}`,body:`<div class="mp-detail-grid"><div><small>Learner</small><strong>${item.learner}</strong></div><div><small>Cohort</small><strong>${item.cohort}</strong></div><div><small>Priority</small><strong>${item.priority}</strong></div><div><small>Status</small><strong>${item.status}</strong></div><div><small>Assigned mentor</small><strong>${item.mentor}</strong></div><div><small>Age</small><strong>${item.age}</strong></div></div><section class="mp-drawer-section"><h3>Learner context</h3><p style="color:var(--muted);font-size:8px;line-height:1.65">The learner attached Question 42 from a recent practice set and asked for a simpler conceptual explanation before the formula method.</p></section><div class="mp-reply-box"><textarea id="doubtReply" placeholder="Write a clear mentor response..."></textarea><div><button class="admin-btn ghost" data-doubt-action="assign" data-id="${item.id}">Assign mentor</button><button class="admin-btn primary" data-doubt-action="resolve" data-id="${item.id}">Reply & resolve</button></div></div>`});
  }

  document.addEventListener('click', event => {
    const classOpen = event.target.closest('[data-class-open]'); if (classOpen) classDetails(classOpen.dataset.classOpen);
    const cohortOpen = event.target.closest('[data-cohort-open]'); if (cohortOpen) cohortDetails(cohortOpen.dataset.cohortOpen);
    const assignmentOpen = event.target.closest('[data-assignment-open]'); if (assignmentOpen) assignmentDetails(assignmentOpen.dataset.assignmentOpen);
    const doubtOpen = event.target.closest('[data-doubt-open]'); if (doubtOpen) doubtDetails(doubtOpen.dataset.doubtOpen);
    const attendanceOpen = event.target.closest('[data-attendance-open]'); if (attendanceOpen) showToast('Attendance register opened for correction review.');
    const classAction = event.target.closest('[data-class-action]'); if (classAction) { showToast(classAction.dataset.classAction === 'studio' ? 'Live studio opened in prototype mode.' : classAction.dataset.classAction === 'notify' ? 'Learner notification queued.' : 'Class editor opened.'); if (classAction.dataset.classAction !== 'edit') closeDrawer(); }
    const cohortAction = event.target.closest('[data-cohort-action]'); if (cohortAction) { if (cohortAction.dataset.cohortAction === 'roster') downloadCsv('cohort-roster.csv',[['Learner','Progress','Attendance'],['Aarav Singh','82%','94%'],['Diya Sharma','79%','91%']]); else showToast(cohortAction.dataset.cohortAction === 'message' ? 'Cohort message composer opened.' : 'Cohort editor opened.'); }
    const assignmentAction = event.target.closest('[data-assignment-action]'); if (assignmentAction) { if (assignmentAction.dataset.assignmentAction === 'export') downloadCsv('assignment-submissions.csv',[['Learner','Submitted','Score'],['Aarav Singh','Yes','18/20'],['Diya Sharma','Yes','17/20']]); else showToast(assignmentAction.dataset.assignmentAction === 'remind' ? 'Incomplete learners will receive a reminder.' : 'Grading workspace opened.'); }
    const doubtAction = event.target.closest('[data-doubt-action]'); if (doubtAction) { const item = state.doubts.find(row=>row.id===doubtAction.dataset.id); if (!item) return; if (doubtAction.dataset.doubtAction === 'resolve') { const reply = $('#doubtReply')?.value.trim(); if (!reply) return showToast('Write a mentor response before resolving.'); item.status='Resolved'; item.age='Resolved just now'; item.mentor=item.mentor==='Unassigned'?'Rohit Sharma':item.mentor; state.audit.unshift({action:'Doubt resolved',detail:item.id,time:new Date().toISOString()}); persist(); renderAll(); closeDrawer(); showToast('Response sent and doubt resolved.'); } else { item.mentor='Rohit Sharma'; item.status='Assigned'; persist(); renderAll(); showToast('Doubt assigned to Rohit Sharma.'); closeDrawer(); } }
  });

  function downloadCsv(filename, rows) {
    const csv = rows.map(row => row.map(value=>`"${String(value).replace(/"/g,'""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
    const link = document.createElement('a'); link.href=url; link.download=filename; link.click(); setTimeout(()=>URL.revokeObjectURL(url),500);
  }

  function scheduleClassModal() {
    const cohortOptions = state.cohorts.map(item=>`<option value="${escapeHtml(item.name)}">${escapeHtml(item.name)}</option>`).join('');
    const mentorOptions = state.mentors.map(item=>`<option value="${escapeHtml(item.name)}">${escapeHtml(item.name)}</option>`).join('');
    openModal(`<span class="eyebrow">LIVE TEACHING</span><h2>Schedule a class</h2><p>Create a live class and assign its cohort, mentor, and delivery settings.</p><form class="mp-form" id="classForm"><label class="full">Class title<input name="title" required placeholder="e.g. Percentage Advanced Drill" /></label><label>Subject<select name="subject"><option>Quantitative Aptitude</option><option>English Language</option><option>Reasoning</option><option>General Awareness</option></select></label><label>Lead mentor<select name="mentor">${mentorOptions}</select></label><label>Cohort<select name="cohort">${cohortOptions}</select></label><label>Date<input name="date" type="date" value="${today}" required /></label><label>Start time<input name="time" type="time" value="17:00" required /></label><label>Duration<select name="duration"><option value="45">45 minutes</option><option value="60" selected>60 minutes</option><option value="75">75 minutes</option><option value="90">90 minutes</option></select></label><label class="full">Teaching notes<textarea name="notes" placeholder="Agenda, resources, or setup instructions..."></textarea></label></form><div class="mp-modal-actions"><button type="button" data-modal-cancel>Cancel</button><button class="primary" type="submit" form="classForm">Schedule class</button></div>`);
    $('#classForm')?.addEventListener('submit', event => { event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget)); state.classes.unshift({id:`CL-${1048+state.classes.length}`,title:data.title,subject:data.subject,mentor:data.mentor,cohort:data.cohort,date:data.date,time:data.time,duration:Number(data.duration),registrations:0,readiness:62,status:'Needs setup'}); persist(); renderAll(); closeModal(); setTab('classes'); showToast('Class scheduled and setup checklist created.'); });
  }
  $('#scheduleClass')?.addEventListener('click', scheduleClassModal);
  $('#openStudio')?.addEventListener('click', () => { setTab('classes'); const live=state.classes.find(item=>item.status==='Live') || state.classes[0]; classDetails(live.id); showToast('Live studio controls are ready.'); });

  $('#inviteMentor')?.addEventListener('click', () => {
    openModal(`<span class="eyebrow">MENTOR NETWORK</span><h2>Invite mentor</h2><p>Create a teaching account and assign an initial subject area.</p><form class="mp-form" id="mentorInviteForm"><label>Full name<input name="name" required placeholder="Mentor name" /></label><label>Email<input name="email" type="email" required placeholder="mentor@example.com" /></label><label>Primary subject<select name="subject"><option>Quantitative Aptitude</option><option>English Language</option><option>Reasoning</option><option>General Awareness</option></select></label><label>Role<select name="role"><option>Lead Mentor</option><option>Associate Mentor</option><option>Doubt Expert</option><option>Guest Faculty</option></select></label><label class="full">Welcome note<textarea name="note" placeholder="Optional onboarding note..."></textarea></label></form><div class="mp-modal-actions"><button data-modal-cancel>Cancel</button><button class="primary" type="submit" form="mentorInviteForm">Send invitation</button></div>`);
    $('#mentorInviteForm')?.addEventListener('submit', event => { event.preventDefault(); const data=Object.fromEntries(new FormData(event.currentTarget)); state.mentors.push({name:data.name,subject:data.subject,open:0,csat:0,classes:0,scoreLift:0}); persist(); renderAll(); closeModal(); showToast(`Invitation sent to ${data.name}.`); });
  });

  $('#createCohort')?.addEventListener('click', () => {
    const mentorOptions=state.mentors.map(item=>`<option>${escapeHtml(item.name)}</option>`).join('');
    openModal(`<span class="eyebrow">COHORT OPERATIONS</span><h2>Create cohort</h2><p>Define the exam, mentor, schedule, and initial learner capacity.</p><form class="mp-form" id="cohortForm"><label class="full">Cohort name<input name="name" required placeholder="e.g. SSC CGL Evening Batch" /></label><label>Target exam<select name="exam"><option>SSC CGL</option><option>SSC CHSL</option><option>Bank PO</option><option>RRB NTPC</option></select></label><label>Lead mentor<select name="mentor">${mentorOptions}</select></label><label>Capacity<input name="learners" type="number" min="20" max="1000" value="300" /></label><label>Schedule<input name="schedule" value="Mon–Sat · 5 PM" /></label></form><div class="mp-modal-actions"><button data-modal-cancel>Cancel</button><button class="primary" type="submit" form="cohortForm">Create cohort</button></div>`);
    $('#cohortForm')?.addEventListener('submit', event=>{event.preventDefault(); const data=Object.fromEntries(new FormData(event.currentTarget)); state.cohorts.unshift({id:`CO-${107+state.cohorts.length}`,name:data.name,exam:data.exam,mentor:data.mentor,learners:Number(data.learners),progress:0,attendance:0,risk:0,health:'Watch',schedule:data.schedule}); persist(); renderAll(); closeModal(); showToast('Cohort created. Learner enrollment can begin.');});
  });

  $('#createAssignment')?.addEventListener('click', () => {
    const cohortOptions=state.cohorts.map(item=>`<option>${escapeHtml(item.name)}</option>`).join('');
    openModal(`<span class="eyebrow">ASSESSMENT OPERATIONS</span><h2>Create assignment</h2><p>Assign a worksheet, quiz, or practice set to a cohort.</p><form class="mp-form" id="assignmentForm"><label class="full">Assignment title<input name="title" required placeholder="Assignment title" /></label><label>Subject<select name="subject"><option>Quantitative Aptitude</option><option>English Language</option><option>Reasoning</option><option>General Awareness</option></select></label><label>Cohort<select name="cohort">${cohortOptions}</select></label><label>Deadline<input name="due" type="datetime-local" required /></label><label>Publishing<select name="status"><option>Open</option><option>Draft</option></select></label><label class="full">Instructions<textarea name="instructions" placeholder="Learner instructions..."></textarea></label></form><div class="mp-modal-actions"><button data-modal-cancel>Cancel</button><button class="primary" type="submit" form="assignmentForm">Create assignment</button></div>`);
    $('#assignmentForm')?.addEventListener('submit', event=>{event.preventDefault(); const data=Object.fromEntries(new FormData(event.currentTarget)); const cohort=state.cohorts.find(item=>item.name===data.cohort); state.assignments.unshift({id:`AS-${214+state.assignments.length}`,title:data.title,cohort:data.cohort,subject:data.subject,due:new Date(data.due).toLocaleString('en-IN',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'}),submitted:0,total:cohort?.learners||300,graded:0,status:data.status}); persist(); renderAll(); closeModal(); showToast('Assignment created and learner targeting saved.');});
  });

  $('#markAttendance')?.addEventListener('click', () => {
    openModal(`<span class="eyebrow">ATTENDANCE</span><h2>Mark attendance</h2><p>Upload or manually confirm attendance for a recent class.</p><form class="mp-form" id="attendanceForm"><label class="full">Session<select name="session">${state.classes.slice(0,8).map(item=>`<option value="${item.id}">${escapeHtml(item.title)} · ${escapeHtml(item.cohort)}</option>`).join('')}</select></label><label>Present<input name="present" type="number" min="0" required /></label><label>Late<input name="late" type="number" min="0" value="0" /></label><label>Absent<input name="absent" type="number" min="0" value="0" /></label><label>Source<select name="source"><option>Live studio</option><option>CSV upload</option><option>Manual register</option></select></label></form><div class="mp-modal-actions"><button data-modal-cancel>Cancel</button><button class="primary" type="submit" form="attendanceForm">Save attendance</button></div>`);
    $('#attendanceForm')?.addEventListener('submit',event=>{event.preventDefault(); const data=Object.fromEntries(new FormData(event.currentTarget)); const cls=state.classes.find(item=>item.id===data.session); const present=Number(data.present),late=Number(data.late),absent=Number(data.absent); state.attendance.unshift({id:`AT-${42+state.attendance.length}`,session:cls.title,cohort:cls.cohort,mentor:cls.mentor,date:'27 Jul · '+cls.time,present,late,absent,total:present+late+absent}); persist(); renderAll(); closeModal(); showToast('Attendance register saved.');});
  });

  document.addEventListener('click', event => { if (event.target.closest('[data-modal-cancel]')) closeModal(); });

  ['classSearch','classStatusFilter','classSubjectFilter','classSort'].forEach(id => $(`#${id}`)?.addEventListener(id==='classSearch'?'input':'change',renderClasses));
  $('#resetClassFilters')?.addEventListener('click',()=>{ $('#classSearch').value=''; $('#classStatusFilter').value='all'; $('#classSubjectFilter').value='all'; renderClasses(); });
  ['cohortSearch','cohortExamFilter','cohortHealthFilter'].forEach(id => $(`#${id}`)?.addEventListener(id==='cohortSearch'?'input':'change',renderCohorts));
  $('#assignmentStatusFilter')?.addEventListener('change',renderAssignments);
  $('#attendanceCohortFilter')?.addEventListener('change',renderAttendance);
  ['doubtPriorityFilter','doubtStatusFilter'].forEach(id=>$(`#${id}`)?.addEventListener('change',renderDoubts));

  const cohortFilter = $('#attendanceCohortFilter');
  state.cohorts.forEach(item => cohortFilter?.insertAdjacentHTML('beforeend',`<option value="${escapeHtml(item.name)}">${escapeHtml(item.name)}</option>`));
  ['reminder24','reminder1','gradingDigest'].forEach(id => { const input=$(`#${id}`); if (!input) return; input.checked=Boolean(state.preferences[id]); input.addEventListener('change',()=>{state.preferences[id]=input.checked;persist();showToast('Assignment automation preference saved.');}); });

  $('#autoAssignDoubts')?.addEventListener('click',()=>{ state.doubts.filter(item=>item.status!=='Resolved'&&item.mentor==='Unassigned').forEach((item,index)=>{const mentor=state.mentors.slice().sort((a,b)=>a.open-b.open)[index%state.mentors.length]; item.mentor=mentor.name; item.status='Assigned'; mentor.open+=1;}); persist();renderAll();showToast('Unassigned doubts distributed by mentor workload.'); });
  $('#exportTeaching')?.addEventListener('click',()=>downloadCsv(`exampro-teaching-report-${today}.csv`,[['Metric','Value'],['Active mentors',state.mentors.length],['Active cohorts',state.cohorts.length],['Classes',state.classes.length],['Open doubts',state.doubts.filter(item=>item.status!=='Resolved').length],['Assignments',state.assignments.length]]));
  $('#classCalendarExport')?.addEventListener('click',()=>{const body=state.classes.map(item=>`BEGIN:VEVENT\nDTSTART:${item.date.replaceAll('-','')}T${item.time.replace(':','')}00\nSUMMARY:${item.title}\nDESCRIPTION:${item.mentor} · ${item.cohort}\nEND:VEVENT`).join('\n');const url=URL.createObjectURL(new Blob([`BEGIN:VCALENDAR\nVERSION:2.0\n${body}\nEND:VCALENDAR`],{type:'text/calendar'}));const a=document.createElement('a');a.href=url;a.download='exampro-teaching-calendar.ics';a.click();setTimeout(()=>URL.revokeObjectURL(url),500);showToast('Teaching calendar exported.');});
  $('#bulkNotify')?.addEventListener('click',()=>showToast('Schedule update sent to registered learners.'));
  $('#openGrading')?.addEventListener('click',()=>showToast('Grading queue opened in prototype mode.'));
  $('#exportAttendance')?.addEventListener('click',()=>downloadCsv('exampro-attendance.csv',[['Session','Cohort','Mentor','Present','Late','Absent'],...state.attendance.map(item=>[item.session,item.cohort,item.mentor,item.present,item.late,item.absent])]));
  $('#sendAttendanceNudge')?.addEventListener('click',()=>showToast('Attendance nudges queued for 126 learners.'));
  $('#exportMentorAnalytics')?.addEventListener('click',()=>downloadCsv('exampro-mentor-analytics.csv',[['Mentor','Subject','CSAT','Classes','Score lift'],...state.mentors.map(item=>[item.name,item.subject,item.csat,item.classes,item.scoreLift])]));
  $('#analyticsPeriod')?.addEventListener('change',event=>showToast(`Analytics updated for ${event.target.value}.`));

  $('#adminSearch')?.addEventListener('input', event => {
    const value=event.target.value.trim();
    if (!value) return;
    const term=value.toLowerCase();
    const matchClass=state.classes.find(item=>[item.title,item.mentor,item.cohort,item.subject].some(v=>v.toLowerCase().includes(term)));
    const matchCohort=state.cohorts.find(item=>[item.name,item.mentor,item.exam].some(v=>v.toLowerCase().includes(term)));
    if (matchClass) { setTab('classes'); $('#classSearch').value=value; renderClasses(); }
    else if (matchCohort) { setTab('cohorts'); $('#cohortSearch').value=value; renderCohorts(); }
  });
  $('#adminAlertBtn')?.addEventListener('click',()=>{setTab('overview');$('.mp-alert-card')?.scrollIntoView({behavior:'smooth',block:'center'});});

  renderAll();
  showToast('Instructor & Mentor Portal is live.');
})();
