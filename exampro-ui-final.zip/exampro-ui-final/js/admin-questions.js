(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const storeKey = 'exampro-admin-question-bank-v1';
  const builderKey = 'exampro-admin-test-builder-v1';
  const importsKey = 'exampro-admin-import-history-v1';
  const reviewKey = 'exampro-admin-review-queue-v1';
  const toast = $('#adminToast');
  let toastTimer;
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
  };
  const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const uid = prefix => `${prefix}-${Math.random().toString(36).slice(2,8).toUpperCase()}`;
  const nowLabel = () => 'Just now';

  const defaultQuestions = [
    {id:'Q-24860',stem:'Choose the word that is most similar in meaning to “ABUNDANT”.',exam:'SSC CGL',subject:'English',topic:'Synonyms',difficulty:'Easy',type:'Single correct MCQ',languages:['EN','HI'],usage:3824,accuracy:74,status:'Published',updated:'12 min ago',source:'SSC CGL 2024',marks:2,negative:.5,options:['Scarce','Plentiful','Limited','Rare'],correct:1,explanation:'Abundant means existing in large quantities; plentiful is the closest synonym.'},
    {id:'Q-24859',stem:'If x + 1/x = 3, find the value of x² + 1/x².',exam:'SSC CGL',subject:'Quantitative Aptitude',topic:'Algebra',difficulty:'Medium',type:'Numerical answer',languages:['EN','HI'],usage:2941,accuracy:61,status:'Review',updated:'28 min ago',source:'Author set',marks:2,negative:.5,options:['5','7','9','11'],correct:1,explanation:'Square the given relation: x² + 2 + 1/x² = 9, therefore x² + 1/x² = 7.'},
    {id:'Q-24858',stem:'Which Article of the Constitution deals with the abolition of untouchability?',exam:'SSC CHSL',subject:'General Awareness',topic:'Indian Polity',difficulty:'Easy',type:'Single correct MCQ',languages:['EN','HI'],usage:6118,accuracy:81,status:'Published',updated:'1 hr ago',source:'NCERT',marks:2,negative:.5,options:['Article 14','Article 15','Article 17','Article 19'],correct:2,explanation:'Article 17 abolishes untouchability and forbids its practice in any form.'},
    {id:'Q-24857',stem:'Find the missing number: 7, 15, 31, 63, ?',exam:'RRB NTPC',subject:'Reasoning',topic:'Number Series',difficulty:'Medium',type:'Single correct MCQ',languages:['EN'],usage:1876,accuracy:68,status:'Flagged',updated:'2 hrs ago',source:'RRB practice',marks:1,negative:.33,options:['95','111','127','129'],correct:2,explanation:'Each term is twice the previous term plus 1; 63 × 2 + 1 = 127.'},
    {id:'Q-24856',stem:'Identify the part of the sentence that contains an error: Neither of the boys / have completed / their assignment / on time.',exam:'SSC CGL',subject:'English',topic:'Error Detection',difficulty:'Medium',type:'Single correct MCQ',languages:['EN','HI'],usage:4317,accuracy:57,status:'Review',updated:'3 hrs ago',source:'Editorial team',marks:2,negative:.5,options:['Neither of the boys','have completed','their assignment','on time'],correct:1,explanation:'The subject “Neither” is singular, so “has completed” should be used.'},
    {id:'Q-24855',stem:'A train crosses a 300 m platform in 30 seconds and a pole in 18 seconds. Find its speed.',exam:'IBPS PO',subject:'Quantitative Aptitude',topic:'Time, Speed & Distance',difficulty:'Hard',type:'Single correct MCQ',languages:['EN','HI'],usage:968,accuracy:42,status:'Draft',updated:'Yesterday',source:'Author set',marks:1,negative:.25,options:['72 km/h','84 km/h','90 km/h','96 km/h'],correct:2,explanation:'Let train length be L. L/v = 18 and (L+300)/v = 30. Thus 300/v = 12, v=25 m/s=90 km/h.'},
    {id:'Q-24854',stem:'Statements: All pens are books. Some books are tables. Conclusions: I. Some pens are tables. II. Some tables are books.',exam:'IBPS PO',subject:'Reasoning',topic:'Syllogism',difficulty:'Medium',type:'Single correct MCQ',languages:['EN','HI'],usage:2084,accuracy:64,status:'Published',updated:'Yesterday',source:'Banking set',marks:1,negative:.25,options:['Only I follows','Only II follows','Both follow','Neither follows'],correct:1,explanation:'The second statement directly establishes that some tables are books. No relationship between pens and tables is certain.'},
    {id:'Q-24853',stem:'The headquarters of the International Solar Alliance is located in which Indian city?',exam:'SSC CGL',subject:'General Awareness',topic:'International Organisations',difficulty:'Easy',type:'Single correct MCQ',languages:['EN','HI'],usage:3291,accuracy:79,status:'Published',updated:'2 days ago',source:'Current affairs 2026',marks:2,negative:.5,options:['New Delhi','Gurugram','Jaipur','Noida'],correct:1,explanation:'The International Solar Alliance headquarters is located in Gurugram, Haryana.'}
  ];

  const defaultReviews = [
    {id:'RV-301',question:'Q-24857',title:'Number series answer key dispute',subject:'Reasoning',issue:'accuracy',priority:true,detail:'Learner reports indicate option C is correct, while the imported key points to option D.',age:'14 hrs',reviewer:'Unassigned'},
    {id:'RV-302',question:'Q-24859',title:'Hindi explanation requires review',subject:'Quantitative Aptitude',issue:'translation',priority:false,detail:'Formula notation was transliterated instead of preserved in mathematical form.',age:'6 hrs',reviewer:'Ravi Kumar'},
    {id:'RV-303',question:'Q-24856',title:'Grammar rationale needs source citation',subject:'English',issue:'accuracy',priority:true,detail:'Add a recognised grammar source and clarify collective subject agreement.',age:'13 hrs',reviewer:'Priya Sharma'},
    {id:'RV-304',question:'Q-24852',title:'New polity question awaiting editorial approval',subject:'General Awareness',issue:'editorial',priority:false,detail:'Source and answer key passed automated validation. Final editorial approval required.',age:'3 hrs',reviewer:'Neha Singh'},
    {id:'RV-305',question:'Q-24851',title:'Hindi option B missing',subject:'English',issue:'translation',priority:false,detail:'The translated question contains only three visible answer options.',age:'2 hrs',reviewer:'Priya Sharma'},
    {id:'RV-306',question:'Q-24850',title:'Difficulty classification inconsistent',subject:'Quantitative Aptitude',issue:'taxonomy',priority:false,detail:'Performance suggests Hard, but imported taxonomy is Easy.',age:'1 hr',reviewer:'Ravi Kumar'}
  ];

  const defaultImports = [
    {id:'IM-9021',name:'ssc-cgl-quant-july.csv',author:'Rajesh Sharma',rows:248,valid:241,status:'Completed',time:'Today · 09:48'},
    {id:'IM-9020',name:'ibps-po-reasoning-set-09.xlsx',author:'Priya Sharma',rows:120,valid:116,status:'Review',time:'Yesterday · 17:20'},
    {id:'IM-9019',name:'current-affairs-week-30.csv',author:'Neha Singh',rows:86,valid:86,status:'Completed',time:'Yesterday · 12:05'}
  ];

  const defaultBuilder = {
    title:'SSC CGL Tier-I Full Mock #19', exam:'SSC CGL', type:'Full Mock', duration:60, access:'ExamPro+ members', status:'Draft',
    sections:[
      {id:'SEC-1',name:'English Language',subject:'English',questions:25,marks:2,negative:.5,pool:2840,easy:35,medium:45,hard:20},
      {id:'SEC-2',name:'Quantitative Aptitude',subject:'Quantitative Aptitude',questions:25,marks:2,negative:.5,pool:2324,easy:25,medium:50,hard:25},
      {id:'SEC-3',name:'General Intelligence',subject:'Reasoning',questions:25,marks:2,negative:.5,pool:2178,easy:30,medium:55,hard:15},
      {id:'SEC-4',name:'General Awareness',subject:'General Awareness',questions:25,marks:2,negative:.5,pool:1600,easy:30,medium:50,hard:20}
    ]
  };

  let questions = (() => { try { return JSON.parse(localStorage.getItem(storeKey)) || defaultQuestions; } catch { return defaultQuestions; } })();
  let reviewItems = (() => { try { return JSON.parse(localStorage.getItem(reviewKey)) || defaultReviews; } catch { return defaultReviews; } })();
  let importHistory = (() => { try { return JSON.parse(localStorage.getItem(importsKey)) || defaultImports; } catch { return defaultImports; } })();
  let builder = (() => { try { return {...defaultBuilder, ...(JSON.parse(localStorage.getItem(builderKey)) || {})}; } catch { return structuredClone(defaultBuilder); } })();
  let selectedQuestions = new Set();
  let currentQuestionId = null;
  let importFileMeta = null;

  const persist = () => {
    localStorage.setItem(storeKey, JSON.stringify(questions));
    localStorage.setItem(reviewKey, JSON.stringify(reviewItems));
    localStorage.setItem(importsKey, JSON.stringify(importHistory));
    localStorage.setItem(builderKey, JSON.stringify(builder));
  };

  function openPanel(name, updateHash = true) {
    $$('[data-workspace]').forEach(button => button.classList.toggle('active', button.dataset.workspace === name));
    $$('[data-workspace-panel]').forEach(panel => panel.classList.toggle('active', panel.dataset.workspacePanel === name));
    if (updateHash) history.replaceState(null, '', name === 'bank' ? location.pathname : `#${name}`);
    if (name === 'builder') renderBuilder();
    if (name === 'review') renderReviews();
  }
  $('#workspaceTabs')?.addEventListener('click', event => {
    const button = event.target.closest('[data-workspace]');
    if (button) openPanel(button.dataset.workspace);
  });
  $$('[data-open-tab]').forEach(button => button.addEventListener('click', () => openPanel(button.dataset.openTab)));
  $$('[data-tab-link]').forEach(link => link.addEventListener('click', event => { event.preventDefault(); openPanel(link.dataset.tabLink); }));

  function statusClass(status) { return status.toLowerCase().replace(/\s+/g, '-'); }
  function classificationMarkup(question) {
    return `<div class="classification"><strong>${escapeHtml(question.subject)}</strong><small>${escapeHtml(question.topic)} · ${escapeHtml(question.difficulty)}</small></div>`;
  }
  function rowMarkup(question) {
    const selected = selectedQuestions.has(question.id);
    return `<tr data-question-row="${escapeHtml(question.id)}">
      <td><label class="qb-check"><input type="checkbox" data-question-select="${escapeHtml(question.id)}" ${selected?'checked':''}/><span></span></label></td>
      <td><div class="question-cell"><span class="question-id">${escapeHtml(question.id.replace('Q-',''))}</span><div class="question-copy"><strong>${escapeHtml(question.stem)}</strong><small><b>${escapeHtml(question.type)}</b><span>${escapeHtml(question.source || 'Original')}</span></small></div></div></td>
      <td>${classificationMarkup(question)}</td>
      <td><div class="language-pills">${question.languages.map(language => `<span class="${language==='HI'?'active':''}">${language}</span>`).join('')}</div></td>
      <td><div class="performance-cell"><strong>${question.usage.toLocaleString('en-IN')} uses · ${question.accuracy}% correct</strong><div class="performance-track"><i style="width:${Math.min(100,question.accuracy)}%"></i></div><small>${question.accuracy < 50 ? 'Needs quality review' : question.accuracy > 75 ? 'Healthy performance' : 'Within expected range'}</small></div></td>
      <td><span class="qb-status ${statusClass(question.status)}">${escapeHtml(question.status)}</span></td>
      <td><span class="qb-updated">${escapeHtml(question.updated)}</span></td>
      <td><div class="qb-row-actions"><button data-question-action="edit" data-id="${question.id}" title="Edit">✎</button><button data-question-action="duplicate" data-id="${question.id}" title="Duplicate">⧉</button><button data-question-action="archive" data-id="${question.id}" title="Archive">•••</button></div></td>
    </tr>`;
  }

  function filteredQuestions() {
    const term = ($('#questionSearch')?.value || '').trim().toLowerCase();
    const exam = $('#examFilter')?.value || 'all';
    const subject = $('#subjectFilter')?.value || 'all';
    const status = $('#statusFilter')?.value || 'all';
    const difficulty = $('#difficultyFilter')?.value || 'all';
    let result = questions.filter(question => {
      const searchable = `${question.id} ${question.stem} ${question.exam} ${question.subject} ${question.topic} ${question.source}`.toLowerCase();
      return (!term || searchable.includes(term)) && (exam === 'all' || question.exam === exam) && (subject === 'all' || question.subject === subject) && (status === 'all' || question.status === status) && (difficulty === 'all' || question.difficulty === difficulty);
    });
    const sort = $('#sortQuestions')?.value || 'updated';
    if (sort === 'usage') result.sort((a,b) => b.usage-a.usage);
    if (sort === 'accuracy') result.sort((a,b) => a.accuracy-b.accuracy);
    if (sort === 'id') result.sort((a,b) => b.id.localeCompare(a.id));
    return result;
  }

  function renderQuestions() {
    const result = filteredQuestions();
    const visible = result.slice(0, 8);
    $('#questionTableBody').innerHTML = visible.length ? visible.map(rowMarkup).join('') : `<tr><td colspan="8"><div class="qb-validation-empty"><span>⌕</span><strong>No matching questions</strong><p>Try changing the search or filters.</p></div></td></tr>`;
    const total = 24860 + Math.max(0, questions.length - defaultQuestions.length);
    $('#questionResultTitle').textContent = result.length === questions.length ? 'All questions' : 'Filtered questions';
    $('#questionResultMeta').textContent = `Showing ${visible.length} of ${result.length === questions.length ? total.toLocaleString('en-IN') : result.length.toLocaleString('en-IN')} questions`;
    $('#paginationText').textContent = visible.length ? `1–${visible.length} of ${result.length === questions.length ? total.toLocaleString('en-IN') : result.length}` : '0 results';
    updateCounts();
  }

  function updateCounts() {
    const added = Math.max(0, questions.length - defaultQuestions.length);
    const total = 24860 + added;
    const publishedAdded = questions.slice(defaultQuestions.length).filter(q => q.status === 'Published').length;
    const reviewAdded = questions.slice(defaultQuestions.length).filter(q => q.status === 'Review').length;
    const flaggedAdded = questions.slice(defaultQuestions.length).filter(q => q.status === 'Flagged').length;
    const reviewCount = 31 + reviewAdded - Math.max(0, defaultReviews.length - reviewItems.length);
    $('#totalQuestions').textContent = total.toLocaleString('en-IN');
    $('#publishedQuestions').textContent = (22914 + publishedAdded).toLocaleString('en-IN');
    $('#reviewQuestions').textContent = Math.max(0, reviewCount).toLocaleString('en-IN');
    $('#flaggedQuestions').textContent = (18 + flaggedAdded).toLocaleString('en-IN');
    $('#bankTabCount').textContent = total.toLocaleString('en-IN');
    $('#reviewTabCount').textContent = Math.max(0, reviewCount);
    $('#sidebarReviewCount').textContent = Math.max(0, reviewCount);
    $('#headerReviewCount').textContent = Math.max(0, reviewCount);
  }

  ['questionSearch','examFilter','subjectFilter','statusFilter','difficultyFilter','sortQuestions'].forEach(id => $(`#${id}`)?.addEventListener(id === 'questionSearch' ? 'input' : 'change', renderQuestions));
  $('#resetFilters')?.addEventListener('click', () => {
    $('#questionSearch').value=''; ['examFilter','subjectFilter','statusFilter','difficultyFilter'].forEach(id => $(`#${id}`).value='all'); $('#sortQuestions').value='updated'; renderQuestions();
  });
  $('#questionTableBody')?.addEventListener('change', event => {
    const input = event.target.closest('[data-question-select]');
    if (!input) return;
    input.checked ? selectedQuestions.add(input.dataset.questionSelect) : selectedQuestions.delete(input.dataset.questionSelect);
    updateBulkState();
  });
  $('#selectAllQuestions')?.addEventListener('change', event => {
    const visible = filteredQuestions().slice(0,8);
    visible.forEach(question => event.target.checked ? selectedQuestions.add(question.id) : selectedQuestions.delete(question.id));
    renderQuestions(); updateBulkState();
  });
  function updateBulkState() {
    $('#selectedCount').textContent = `${selectedQuestions.size} selected`;
    $('#bulkBar').classList.toggle('has-selection', selectedQuestions.size > 0);
    const visible = filteredQuestions().slice(0,8);
    $('#selectAllQuestions').checked = visible.length > 0 && visible.every(q => selectedQuestions.has(q.id));
  }
  $('.qb-bulk-actions')?.addEventListener('click', event => {
    const button = event.target.closest('[data-bulk]');
    if (!button || !selectedQuestions.size) return;
    const action = button.dataset.bulk;
    if (action === 'duplicate') {
      const duplicates = questions.filter(q => selectedQuestions.has(q.id)).map(q => ({...q,id:uid('Q'),stem:`${q.stem} (Copy)`,status:'Draft',updated:nowLabel(),usage:0}));
      questions.unshift(...duplicates); showToast(`${duplicates.length} questions duplicated as drafts.`);
    } else if (action === 'archive') {
      questions = questions.filter(q => !selectedQuestions.has(q.id)); showToast(`${selectedQuestions.size} questions archived.`);
    } else {
      const status = action === 'publish' ? 'Published' : 'Review';
      questions.forEach(q => { if(selectedQuestions.has(q.id)){ q.status=status; q.updated=nowLabel(); }}); showToast(`${selectedQuestions.size} questions moved to ${status.toLowerCase()}.`);
    }
    selectedQuestions.clear(); persist(); renderQuestions(); updateBulkState();
  });
  $$('.qb-view-actions [data-view]').forEach(button => button.addEventListener('click', () => {
    $$('.qb-view-actions [data-view]').forEach(item => item.classList.toggle('active', item === button));
    $('.qb-table').classList.toggle('compact', button.dataset.view === 'compact');
  }));

  function buildOptionEditors() {
    const letters = ['A','B','C','D'];
    $('#optionEditorEn').innerHTML = letters.map((letter,index)=>`<label><i>${letter}</i><input type="text" id="optionEn${index}" placeholder="Option ${letter}" required/><input type="radio" name="correctAnswer" value="${index}" ${index===0?'checked':''} aria-label="Mark option ${letter} correct"/></label>`).join('');
    $('#optionEditorHi').innerHTML = letters.map((letter,index)=>`<label><i>${letter}</i><input type="text" id="optionHi${index}" placeholder="विकल्प ${letter}"/><span></span></label>`).join('');
  }
  buildOptionEditors();
  const openModal = id => { const modal=$(`#${id}`); modal?.classList.add('open'); modal?.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden'; };
  const closeModal = id => { const modal=$(`#${id}`); modal?.classList.remove('open'); modal?.setAttribute('aria-hidden','true'); if(!$('.qb-modal-backdrop.open')) document.body.style.overflow=''; };
  $$('[data-close-modal]').forEach(button => button.addEventListener('click', () => closeModal(button.dataset.closeModal)));
  $$('.qb-modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', event => { if(event.target===backdrop) closeModal(backdrop.id); }));
  document.addEventListener('keydown', event => { if(event.key==='Escape') $$('.qb-modal-backdrop.open').forEach(modal => closeModal(modal.id)); });
  function resetQuestionForm() {
    currentQuestionId=null; $('#questionModalTitle').textContent='Create new question'; $('#questionModalSubtitle').textContent='Add content, scoring, explanation, and classification.'; $('#questionForm').reset(); buildOptionEditors(); $('#questionDifficulty').value='Medium'; $('#questionMarks').value='2'; $('#questionNegative').value='0.5'; $('#questionAccessibility').checked=true; $('#questionAiCheck').checked=true; $('#translationStatus').textContent='Hindi translation required';
  }
  $('#createQuestion')?.addEventListener('click', () => { resetQuestionForm(); openModal('questionModal'); });
  $('#languageTabs')?.addEventListener('click', event => {
    const button=event.target.closest('[data-language-tab]'); if(!button)return;
    $$('#languageTabs button').forEach(item=>item.classList.toggle('active',item===button));
    $$('[data-language-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.languagePanel===button.dataset.languageTab));
  });
  function formQuestion(status='Review') {
    const options=[0,1,2,3].map(i=>$(`#optionEn${i}`).value.trim());
    const hindiOptions=[0,1,2,3].map(i=>$(`#optionHi${i}`)?.value.trim()).filter(Boolean);
    const correct=Number($('input[name="correctAnswer"]:checked')?.value || 0);
    return {
      id:currentQuestionId || uid('Q'), stem:$('#questionStemEn').value.trim(), exam:$('#questionExam').value, subject:$('#questionSubject').value, topic:$('#questionTopic').value.trim()||'Unclassified', difficulty:$('#questionDifficulty').value, type:$('#questionType').value, languages:$('#questionStemHi').value.trim() || hindiOptions.length ? ['EN','HI'] : ['EN'], usage:currentQuestionId ? (questions.find(q=>q.id===currentQuestionId)?.usage||0) : 0, accuracy:currentQuestionId ? (questions.find(q=>q.id===currentQuestionId)?.accuracy||0) : 0, status, updated:nowLabel(), source:$('#questionSource').value.trim()||'Admin authoring', marks:Number($('#questionMarks').value)||0, negative:Number($('#questionNegative').value)||0, options, correct, explanation:$('#questionExplanationEn').value.trim(), hindi:{stem:$('#questionStemHi').value.trim(),options:hindiOptions,explanation:$('#questionExplanationHi').value.trim()},tags:$('#questionTags').value.split(',').map(v=>v.trim()).filter(Boolean)
    };
  }
  $('#questionForm')?.addEventListener('submit', event => {
    event.preventDefault();
    const item=formQuestion('Review');
    if(!item.stem || item.options.some(option=>!option)){ showToast('Complete the English question and all four options.'); return; }
    if(currentQuestionId){ const index=questions.findIndex(q=>q.id===currentQuestionId); questions[index]=item; }
    else questions.unshift(item);
    reviewItems.unshift({id:uid('RV'),question:item.id,title:`Editorial review: ${item.topic}`,subject:item.subject,issue:item.languages.includes('HI')?'editorial':'translation',priority:false,detail:'Newly authored question requires answer-key, source, and translation review.',age:'Just now',reviewer:'Unassigned'});
    persist(); renderQuestions(); renderReviews(); closeModal('questionModal'); showToast(currentQuestionId?'Question updated and returned to review.':'Question created and sent to review.');
  });
  $('#saveQuestionDraft')?.addEventListener('click', () => {
    const item=formQuestion('Draft');
    if(!item.stem){showToast('Enter a question stem before saving.');return;}
    if(currentQuestionId){const index=questions.findIndex(q=>q.id===currentQuestionId);questions[index]=item;}else questions.unshift(item);
    persist(); renderQuestions(); closeModal('questionModal'); showToast('Question saved as draft.');
  });
  $('#questionTableBody')?.addEventListener('click', event => {
    const button=event.target.closest('[data-question-action]'); if(!button)return;
    const item=questions.find(q=>q.id===button.dataset.id); if(!item)return;
    if(button.dataset.questionAction==='edit'){
      resetQuestionForm(); currentQuestionId=item.id; $('#questionModalTitle').textContent=`Edit ${item.id}`; $('#questionStemEn').value=item.stem; $('#questionExplanationEn').value=item.explanation||''; $('#questionExam').value=item.exam; $('#questionSubject').value=item.subject; $('#questionTopic').value=item.topic; $('#questionDifficulty').value=item.difficulty; $('#questionType').value=item.type; $('#questionSource').value=item.source||''; $('#questionMarks').value=item.marks; $('#questionNegative').value=item.negative; $('#questionTags').value=(item.tags||[]).join(', '); item.options.forEach((option,index)=>{ $(`#optionEn${index}`).value=option; }); const radio=$(`input[name="correctAnswer"][value="${item.correct}"]`); if(radio) radio.checked=true; if(item.hindi){$('#questionStemHi').value=item.hindi.stem||'';$('#questionExplanationHi').value=item.hindi.explanation||'';(item.hindi.options||[]).forEach((option,index)=>{if($(`#optionHi${index}`))$(`#optionHi${index}`).value=option;});} openModal('questionModal');
    } else if(button.dataset.questionAction==='duplicate') {
      questions.unshift({...item,id:uid('Q'),stem:`${item.stem} (Copy)`,status:'Draft',updated:nowLabel(),usage:0});persist();renderQuestions();showToast('Question duplicated as draft.');
    } else {
      const confirmed=confirm(`Archive ${item.id}?`); if(confirmed){questions=questions.filter(q=>q.id!==item.id);persist();renderQuestions();showToast('Question archived.');}
    }
  });

  function downloadCsv(name, rows) {
    const csv=rows.map(row=>row.map(cell=>`"${String(cell).replace(/"/g,'""')}"`).join(',')).join('\n');
    const blob=new Blob([csv],{type:'text/csv'}); const link=document.createElement('a'); link.href=URL.createObjectURL(blob); link.download=name; link.click(); URL.revokeObjectURL(link.href);
  }
  function downloadTemplate() {
    downloadCsv('exampro-question-import-template.csv', [['source_id','exam','subject','topic','difficulty','question_en','option_a_en','option_b_en','option_c_en','option_d_en','correct_option','explanation_en','question_hi','option_a_hi','option_b_hi','option_c_hi','option_d_hi','explanation_hi','marks','negative_marks','tags'],['SRC-001','SSC CGL','English','Synonyms','Easy','Choose the synonym of ABUNDANT','Scarce','Plentiful','Limited','Rare','B','Abundant means plentiful','','','','','','','2','0.5','vocabulary;tier-1']]);
    showToast('Import template downloaded.');
  }
  $('#downloadTemplate')?.addEventListener('click',downloadTemplate); $('#importTemplateSecondary')?.addEventListener('click',downloadTemplate);
  const importDropzone=$('#importDropzone');
  ['dragenter','dragover'].forEach(type=>importDropzone?.addEventListener(type,event=>{event.preventDefault();importDropzone.classList.add('dragover');}));
  ['dragleave','drop'].forEach(type=>importDropzone?.addEventListener(type,event=>{event.preventDefault();importDropzone.classList.remove('dragover');}));
  importDropzone?.addEventListener('drop',event=>{const file=event.dataTransfer.files[0];if(file)selectImportFile(file);});
  $('#importFile')?.addEventListener('change',event=>{const file=event.target.files[0];if(file)selectImportFile(file);});
  function selectImportFile(file){
    importFileMeta={name:file.name,size:file.size,rows:Math.max(28,Math.min(480,Math.round(file.size/185)||120))};
    importDropzone.querySelector('strong').textContent=file.name; importDropzone.querySelector('p').textContent=`${(file.size/1024).toFixed(1)} KB · ready to validate`; importDropzone.querySelector('button').textContent='Replace file'; $('#validateImport').disabled=false; $('#validationSubtitle').textContent='File selected. Run validation to inspect content quality.'; showToast(`${file.name} selected.`);
  }
  $('#validateImport')?.addEventListener('click',event=>{
    if(!importFileMeta)return; const button=event.currentTarget; button.disabled=true; button.textContent='Validating columns and answers…';
    setTimeout(()=>{
      const total=importFileMeta.rows, errors=Math.max(2,Math.round(total*.035)), warnings=Math.max(3,Math.round(total*.055)), duplicates=$('#skipDuplicates').checked?Math.max(1,Math.round(total*.025)):0, valid=total-errors-duplicates;
      $('#validationEmpty').hidden=true;$('#validationResults').hidden=false;$('#validationState').className='qb-validation-state ready';$('#validationState').textContent='Validated';$('#validationSubtitle').textContent=`${importFileMeta.name} · ${total} detected rows`;$('#validRows').textContent=valid;$('#warningRows').textContent=warnings;$('#errorRows').textContent=errors;$('#duplicateRows').textContent=duplicates;const rate=Math.round(valid/total*100);$('#validationRate').textContent=`${rate}%`;$('#validationBar').style.width=`${rate}%`;$('#validationIssues').innerHTML=`<article class="error"><span>×</span><div><strong>${errors} rows have invalid answer keys</strong><p>Correct option does not match A, B, C, or D.</p></div><em>Rows 18, 41…</em></article><article class="warning"><span>!</span><div><strong>${warnings} Hindi explanations are missing</strong><p>Rows remain importable but need translation review.</p></div><em>Review required</em></article><article class="warning"><span>≈</span><div><strong>${duplicates} likely duplicates detected</strong><p>Matched against normalized English stems.</p></div><em>Will be skipped</em></article>`;
      importFileMeta={...importFileMeta,total,errors,warnings,duplicates,valid};button.disabled=false;button.textContent='Run validation again';showToast(`Validation complete: ${valid} valid rows.`);
    },850);
  });
  $('#commitImport')?.addEventListener('click',()=>{
    if(!importFileMeta?.valid)return;
    const createCount=Math.min(importFileMeta.valid,20);
    const subjects=['English','Quantitative Aptitude','Reasoning','General Awareness'];
    for(let i=0;i<createCount;i++) questions.unshift({id:uid('Q'),stem:`Imported sample question ${i+1} from ${importFileMeta.name}`,exam:$('#importExam').value,subject:subjects[i%4],topic:'Imported batch',difficulty:['Easy','Medium','Hard'][i%3],type:'Single correct MCQ',languages:$('#importLanguage').value.includes('Hindi')?['EN','HI']:['EN'],usage:0,accuracy:0,status:$('#autoReview').checked?'Review':'Draft',updated:nowLabel(),source:importFileMeta.name,marks:2,negative:.5,options:['Option A','Option B','Option C','Option D'],correct:1,explanation:'Imported explanation pending editorial verification.'});
    importHistory.unshift({id:uid('IM'),name:importFileMeta.name,author:'Amit Kumar',rows:importFileMeta.total,valid:importFileMeta.valid,status:$('#autoReview').checked?'Review':'Completed',time:'Just now'});
    persist();renderQuestions();renderImportHistory();showToast(`${importFileMeta.valid} valid questions imported. ${createCount} are represented in this frontend dataset.`);openPanel('bank');
  });
  $('#downloadErrors')?.addEventListener('click',()=>downloadCsv('exampro-import-errors.csv',[['row','column','issue'],['18','correct_option','Expected A, B, C, or D'],['41','question_hi','Translation missing'],['67','source_id','Duplicate source ID']]));
  function renderImportHistory(){
    $('#importHistoryList').innerHTML=importHistory.map(item=>`<article><span>▦</span><div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.id)} · ${escapeHtml(item.author)}</small></div><div><div class="history-progress"><i style="width:${Math.round(item.valid/item.rows*100)}%"></i></div><small>${item.valid} valid of ${item.rows} rows</small></div><em>${escapeHtml(item.status)}</em><small>${escapeHtml(item.time)}</small></article>`).join('');
  }
  $('#clearImportHistory')?.addEventListener('click',()=>{importHistory=importHistory.filter(item=>item.status!=='Completed');persist();renderImportHistory();showToast('Completed import history cleared.');});

  function sectionMarkup(section,index){
    return `<article class="builder-section" data-section-id="${section.id}"><div class="builder-section-head"><span class="builder-section-index">${index+1}</span><label><span>Section name</span><input data-field="name" value="${escapeHtml(section.name)}" /></label><label><span>Subject</span><select data-field="subject"><option ${section.subject==='English'?'selected':''}>English</option><option ${section.subject==='Quantitative Aptitude'?'selected':''}>Quantitative Aptitude</option><option ${section.subject==='Reasoning'?'selected':''}>Reasoning</option><option ${section.subject==='General Awareness'?'selected':''}>General Awareness</option></select></label><label><span>Questions</span><input data-field="questions" type="number" min="1" max="100" value="${section.questions}" /></label><label><span>Marks / question</span><input data-field="marks" type="number" step=".25" value="${section.marks}" /></label><label><span>Negative</span><input data-field="negative" type="number" step=".25" value="${section.negative}" /></label><div class="builder-section-actions"><button data-section-action="autofill" title="Auto-pick questions">✦</button><button data-section-action="remove" title="Remove section">×</button></div></div><div class="builder-section-rules"><div class="builder-rule-chip"><span>Available pool</span><strong>${section.pool.toLocaleString('en-IN')} questions</strong></div><div class="builder-rule-chip"><span>Easy allocation</span><strong>${section.easy}%</strong></div><div class="builder-rule-chip"><span>Medium allocation</span><strong>${section.medium}%</strong></div><div class="builder-rule-chip"><span>Hard allocation</span><strong>${section.hard}%</strong></div></div></article>`;
  }
  function syncBuilderFromInputs(){
    builder.title=$('#testTitle')?.value||builder.title;builder.exam=$('#testExam')?.value||builder.exam;builder.type=$('#testType')?.value||builder.type;builder.duration=Number($('#testDuration')?.value)||builder.duration;builder.access=$('#testAccess')?.value||builder.access;
  }
  function renderBuilder(){
    if(!$('#builderSections'))return;
    $('#testTitle').value=builder.title;$('#testExam').value=builder.exam;$('#testType').value=builder.type;$('#testDuration').value=builder.duration;$('#testAccess').value=builder.access;$('#builderSections').innerHTML=builder.sections.map(sectionMarkup).join('');
    updateBuilderSummary();
  }
  function updateBuilderSummary(){
    syncBuilderFromInputs();
    const totalQuestions=builder.sections.reduce((sum,s)=>sum+Number(s.questions||0),0);const totalMarks=builder.sections.reduce((sum,s)=>sum+Number(s.questions||0)*Number(s.marks||0),0);const totalPool=builder.sections.reduce((sum,s)=>sum+Number(s.pool||0),0);const weighted=(key)=>totalQuestions?Math.round(builder.sections.reduce((sum,s)=>sum+Number(s.questions||0)*Number(s[key]||0),0)/totalQuestions):0;
    $('#builderTotalQuestions').textContent=totalQuestions;$('#builderTotalMarks').textContent=totalMarks.toFixed(totalMarks%1?1:0);$('#builderDurationSummary').textContent=`${builder.duration} min`;$('#builderSectionCount').textContent=builder.sections.length;$('#builderPoolSize').textContent=totalPool.toLocaleString('en-IN');$('#easyBalance').textContent=`${weighted('easy')}%`;$('#mediumBalance').textContent=`${weighted('medium')}%`;$('#hardBalance').textContent=`${weighted('hard')}%`;$('.builder-balance b.easy').style.width=`${weighted('easy')}%`;$('.builder-balance b.medium').style.width=`${weighted('medium')}%`;$('.builder-balance b.hard').style.width=`${weighted('hard')}%`;$('#previewTestTitle').textContent=builder.title;$('#previewQuestionCount').textContent=totalQuestions;
    const warnings=[];if(totalQuestions!==100)warnings.push(`<p class="warning"><span>!</span>This blueprint contains ${totalQuestions} questions instead of the recommended 100.</p>`);if(builder.sections.some(s=>Number(s.questions)>Number(s.pool)))warnings.push('<p class="warning"><span>!</span>One or more sections request more questions than the available pool.</p>');if(!warnings.length)warnings.push('<p class="success"><span>✓</span>Blueprint is balanced and ready for review.</p>');$('#builderWarnings').innerHTML=warnings.join('');
    persist();
  }
  $('#builderSections')?.addEventListener('input',event=>{
    const sectionEl=event.target.closest('[data-section-id]');if(!sectionEl)return;const section=builder.sections.find(s=>s.id===sectionEl.dataset.sectionId);if(!section)return;const field=event.target.dataset.field;if(field)section[field]=['questions','marks','negative'].includes(field)?Number(event.target.value):event.target.value;updateBuilderSummary();$('#builderSaveState').textContent='Unsaved changes';
  });
  $('#builderSections')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-section-action]');if(!button)return;const sectionEl=button.closest('[data-section-id]');const index=builder.sections.findIndex(s=>s.id===sectionEl.dataset.sectionId);if(index<0)return;
    if(button.dataset.sectionAction==='remove'){if(builder.sections.length<=1){showToast('A test must contain at least one section.');return;}builder.sections.splice(index,1);renderBuilder();showToast('Section removed.');}
    else{const section=builder.sections[index];section.pool+=Math.floor(Math.random()*180);section.easy=30;section.medium=50;section.hard=20;renderBuilder();showToast(`${section.name} question mix auto-balanced.`);}
  });
  $('#addSection')?.addEventListener('click',()=>{builder.sections.push({id:uid('SEC'),name:`New Section ${builder.sections.length+1}`,subject:'English',questions:10,marks:1,negative:.25,pool:860,easy:30,medium:50,hard:20});renderBuilder();showToast('New section added.');});
  ['testTitle','testExam','testType','testDuration','testAccess','testStart','testEnd','testDescription','testInstructions','resultRelease','leaderboardMode'].forEach(id=>$(`#${id}`)?.addEventListener('input',()=>{$('#builderSaveState').textContent='Unsaved changes';updateBuilderSummary();}));
  $('#saveTestDraft')?.addEventListener('click',()=>{syncBuilderFromInputs();builder.status='Draft';persist();$('#builderSaveState').textContent='Saved locally';$('#builderStatus').textContent='Draft';$('#builderStatus').className='builder-status draft';const list=$('#builderVersionList');list.insertAdjacentHTML('afterbegin',`<article><span>v0.${list.children.length+2}</span><div><strong>Draft saved</strong><small>Amit · just now</small></div></article>`);showToast('Test draft saved locally.');});
  $('#sendTestReview')?.addEventListener('click',()=>{syncBuilderFromInputs();builder.status='Review';persist();$('#builderStatus').textContent='In review';$('#builderStatus').className='builder-status review';$('#builderSaveState').textContent='Submitted for approval';reviewItems.unshift({id:uid('RV'),question:'TEST-BUILD',title:`Test approval: ${builder.title}`,subject:builder.exam,issue:'editorial',priority:true,detail:`${builder.sections.length} sections and ${builder.sections.reduce((a,s)=>a+s.questions,0)} questions require final publishing approval.`,age:'Just now',reviewer:'Unassigned'});persist();renderReviews();updateCounts();showToast('Test sent to the approval queue.');});
  $('#previewTest')?.addEventListener('click',()=>{syncBuilderFromInputs();updateBuilderSummary();openModal('previewModal');});
  $('#openLearnerPreview')?.addEventListener('click',()=>location.href='instructions.html');

  function reviewMarkup(item){
    return `<article class="review-item ${item.priority?'priority':''}" data-review-id="${item.id}" data-review-type="${item.issue}"><span>${item.priority?'!':'✓'}</span><div class="review-copy"><strong>${escapeHtml(item.title)}</strong><small><b>${escapeHtml(item.question)}</b><span>${escapeHtml(item.subject)}</span><span>${escapeHtml(item.age)}</span></small></div><div class="review-issue"><strong>${escapeHtml(item.issue[0].toUpperCase()+item.issue.slice(1))} review</strong><p>${escapeHtml(item.detail)}</p></div><div class="review-actions"><button class="approve" data-review-action="approve">Approve</button><button class="changes" data-review-action="changes">Request changes</button><button data-review-action="open">Open</button></div></article>`;
  }
  function renderReviews(filter='all'){
    const items=reviewItems.filter(item=>filter==='all'||(filter==='priority'&&item.priority)||item.issue===filter);$('#reviewList').innerHTML=items.length?items.map(reviewMarkup).join(''):`<div class="qb-validation-empty"><span>✓</span><strong>Queue is clear</strong><p>No review items match this filter.</p></div>`;updateCounts();
  }
  $('#reviewFilters')?.addEventListener('click',event=>{const button=event.target.closest('[data-review-filter]');if(!button)return;$$('#reviewFilters button').forEach(item=>item.classList.toggle('active',item===button));renderReviews(button.dataset.reviewFilter);});
  $('#reviewList')?.addEventListener('click',event=>{
    const button=event.target.closest('[data-review-action]');if(!button)return;const row=button.closest('[data-review-id]');const item=reviewItems.find(entry=>entry.id===row.dataset.reviewId);if(!item)return;
    if(button.dataset.reviewAction==='approve'){reviewItems=reviewItems.filter(entry=>entry.id!==item.id);const question=questions.find(q=>q.id===item.question);if(question){question.status='Published';question.updated=nowLabel();}showToast(`${item.question} approved and published.`);}
    else if(button.dataset.reviewAction==='changes'){reviewItems=reviewItems.filter(entry=>entry.id!==item.id);const question=questions.find(q=>q.id===item.question);if(question){question.status='Draft';question.updated=nowLabel();}showToast(`Changes requested for ${item.question}.`);}
    else{const question=questions.find(q=>q.id===item.question);if(question){currentQuestionId=question.id;$('#questionTableBody')?.querySelector(`[data-id="${question.id}"][data-question-action="edit"]`)?.click();}else showToast('Test approval detail opened in the Test Builder.');}
    persist();renderReviews();renderQuestions();
  });
  $('#autoAssign')?.addEventListener('click',()=>{const names=['Priya Sharma','Ravi Kumar','Neha Singh','Arjun Mehta'];reviewItems.forEach((item,index)=>{if(item.reviewer==='Unassigned')item.reviewer=names[index%names.length];});persist();showToast('Unassigned review work distributed by subject expertise.');});

  $('#adminAlertBtn')?.addEventListener('click',()=>openPanel('review'));
  $('#adminSearch')?.addEventListener('input',event=>{const term=event.target.value.trim();if(term.length>1){openPanel('bank',false);$('#questionSearch').value=term;renderQuestions();}});

  renderImportHistory(); renderQuestions(); renderReviews(); renderBuilder(); updateBulkState();
  const initialHash=location.hash.replace('#',''); if(['import','builder','review'].includes(initialHash))openPanel(initialHash,false);
  showToast('Question operations workspace ready.');
})();
