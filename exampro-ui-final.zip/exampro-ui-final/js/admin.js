(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const shell = $('.admin-shell');
  const toast = $('#adminToast');
  let toastTimer;
  const showToast = message => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
  };

  $('#adminCollapse')?.addEventListener('click', () => {
    shell?.classList.toggle('collapsed');
    localStorage.setItem('exampro-admin-collapsed', shell?.classList.contains('collapsed') ? '1' : '0');
  });
  if (localStorage.getItem('exampro-admin-collapsed') === '1' && innerWidth > 1120) shell?.classList.add('collapsed');
  $('#adminMenu')?.addEventListener('click', () => shell?.classList.toggle('mobile-open'));
  document.addEventListener('click', event => {
    if (innerWidth <= 820 && shell?.classList.contains('mobile-open') && !event.target.closest('.admin-sidebar') && !event.target.closest('#adminMenu')) shell.classList.remove('mobile-open');
  });

  $('#adminTheme')?.addEventListener('click', () => {
    const html = document.documentElement;
    const next = html.dataset.theme === 'light' ? 'dark' : 'light';
    html.dataset.theme = next;
    localStorage.setItem('exampro-theme', next);
    showToast(`${next[0].toUpperCase() + next.slice(1)} theme enabled.`);
  });

  const modal = $('#adminModal');
  const openModal = (title, copy, icon = '✦') => {
    $('#adminModalTitle').textContent = title;
    $('#adminModalCopy').textContent = copy;
    $('#adminModalIcon').textContent = icon;
    modal?.classList.add('open');
    modal?.setAttribute('aria-hidden', 'false');
  };
  const closeModal = () => { modal?.classList.remove('open'); modal?.setAttribute('aria-hidden', 'true'); };
  ['adminModalClose', 'adminModalCancel'].forEach(id => $(`#${id}`)?.addEventListener('click', closeModal));
  modal?.addEventListener('click', event => { if (event.target === modal) closeModal(); });
  $('#adminModalPrimary')?.addEventListener('click', () => { closeModal(); showToast('Added to the operations roadmap.'); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
  $$('[data-href]').forEach(element => element.addEventListener('click', () => { window.location.href = element.dataset.href; }));

  $$('[data-future]').forEach(element => element.addEventListener('click', event => {
    event.preventDefault();
    const name = element.dataset.future;
    openModal(name, `${name} is planned for the next admin operations sprint. This Overview establishes the shared administrative design system and navigation.`, element.querySelector('span')?.textContent || '✦');
  }));

  $('#viewAlerts')?.addEventListener('click', () => openModal('Operational action queue', 'The queue consolidates support, moderation, approval, billing and identity-verification work. Dedicated workflows arrive in Sprints 32–36.', '!'));
  $('#adminAlertBtn')?.addEventListener('click', () => $('#adminAlertStrip')?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
  $('#closeAdminAlert')?.addEventListener('click', () => $('#adminAlertStrip')?.remove());
  $('#adminProfile')?.addEventListener('click', () => openModal('Administrator account', 'Role: Super Administrator. Last secure login: Today at 09:42 IST. Two-step verification is active.', 'AK'));

  const metricConfig = {
    learners: {
      label: 'Active learners', value: '18,426', delta: '+12.8% vs previous period', subtitle: 'Daily active learners for the last 7 days',
      line: 'M30 220 C105 205,160 180,220 187 S330 142,410 149 S530 104,600 119 S715 61,800 70',
      area: 'M30 220 C105 205,160 180,220 187 S330 142,410 149 S530 104,600 119 S715 61,800 70 L800 245 L30 245 Z',
      previous: 'M30 214 C110 192,150 204,220 172 S340 168,410 138 S530 143,600 110 S720 116,800 84',
      points: [[30,220],[160,180],[285,151],[410,149],[535,104],[665,87],[800,70]]
    },
    revenue: {
      label: 'Gross revenue', value: '₹4.72L', delta: '+9.7% vs previous period', subtitle: 'Revenue collected for the last 7 days',
      line: 'M30 205 C100 210,155 164,220 178 S335 115,410 137 S525 82,600 103 S710 54,800 62',
      area: 'M30 205 C100 210,155 164,220 178 S335 115,410 137 S525 82,600 103 S710 54,800 62 L800 245 L30 245 Z',
      previous: 'M30 217 C110 202,150 194,220 185 S340 151,410 158 S535 119,600 124 S720 92,800 90',
      points: [[30,205],[160,164],[285,148],[410,137],[535,82],[665,76],[800,62]]
    },
    attempts: {
      label: 'Test attempts', value: '12,846', delta: '+16.2% vs previous period', subtitle: 'Daily test attempts for the last 7 days',
      line: 'M30 228 C105 188,155 207,220 168 S340 193,410 130 S520 146,600 95 S720 104,800 52',
      area: 'M30 228 C105 188,155 207,220 168 S340 193,410 130 S520 146,600 95 S720 104,800 52 L800 245 L30 245 Z',
      previous: 'M30 224 C105 214,160 190,220 199 S330 175,410 166 S520 148,600 136 S720 113,800 102',
      points: [[30,228],[160,197],[285,181],[410,130],[535,135],[665,99],[800,52]]
    }
  };
  function renderMetric(metric) {
    const config = metricConfig[metric];
    if (!config) return;
    $('#chartMetricLabel').textContent = config.label;
    $('#chartMetricValue').textContent = config.value;
    $('#chartMetricDelta').textContent = config.delta;
    $('#trendSubtitle').textContent = config.subtitle;
    $('#growthLine').setAttribute('d', config.line);
    $('#growthArea').setAttribute('d', config.area);
    $('#previousLine').setAttribute('d', config.previous);
    $('#growthPoints').innerHTML = config.points.map(([cx, cy], index) => `<circle cx="${cx}" cy="${cy}" r="${index === config.points.length - 1 ? 6 : 5}"/>`).join('');
    $$('#metricTabs button').forEach(button => button.classList.toggle('active', button.dataset.metric === metric));
  }
  $('#metricTabs')?.addEventListener('click', event => {
    const button = event.target.closest('[data-metric]');
    if (button) renderMetric(button.dataset.metric);
  });

  const ranges = {
    today: {learners:'6,248',paid:'147',attempts:'12,846',mrr:'₹2.1L',tickets:'47',uptime:'99.99%'},
    '7d': {learners:'18,426',paid:'4,218',attempts:'68,352',mrr:'₹4.72L',tickets:'47',uptime:'99.98%'},
    '30d': {learners:'42,918',paid:'4,218',attempts:'2,84,610',mrr:'₹18.4L',tickets:'126',uptime:'99.98%'},
    '90d': {learners:'78,640',paid:'8,946',attempts:'8,72,404',mrr:'₹51.8L',tickets:'384',uptime:'99.96%'}
  };
  $('#adminRange')?.addEventListener('change', event => {
    const values = ranges[event.target.value] || ranges['7d'];
    Object.entries(values).forEach(([key, value]) => { const el = $(`[data-admin-kpi="${key}"]`); if (el) el.textContent = value; });
    showToast(`Dashboard updated for ${event.target.options[event.target.selectedIndex].text}.`);
  });

  $('#refreshAdmin')?.addEventListener('click', event => {
    const button = event.currentTarget;
    button.disabled = true;
    button.innerHTML = '<span class="admin-spin">↻</span> Refreshing';
    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = '<span>↻</span> Refresh';
      const active = $('[data-admin-kpi="learners"]');
      if (active) active.textContent = (Number(active.textContent.replace(/,/g, '')) + 23).toLocaleString('en-IN');
      showToast('Live platform metrics refreshed.');
    }, 900);
  });

  $('#exportAdmin')?.addEventListener('click', () => {
    const rows = [['Metric','Value'], ...$$('[data-admin-kpi]').map(el => [el.closest('.admin-kpi').querySelector(':scope > small').textContent, el.textContent])];
    const csv = rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], {type:'text/csv'});
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `exampro-admin-snapshot-${new Date().toISOString().slice(0,10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
    showToast('Administrative snapshot exported.');
  });

  $('#activityFilters')?.addEventListener('click', event => {
    const button = event.target.closest('[data-activity]');
    if (!button) return;
    const filter = button.dataset.activity;
    $$('#activityFilters button').forEach(item => item.classList.toggle('active', item === button));
    $$('[data-activity-row]').forEach(row => row.hidden = filter !== 'all' && row.dataset.activityRow !== filter);
  });

  $('#adminSearch')?.addEventListener('keydown', event => {
    if (event.key !== 'Enter') return;
    const term = event.currentTarget.value.trim();
    if (!term) return;
    openModal('Admin search', `No production index is connected in this frontend prototype. The query “${term}” is ready to be routed to users, tests, transactions and content records.`, '⌕');
  });
  document.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      $('#adminSearch')?.focus();
    }
  });

  $$('.row-menu').forEach(button => button.addEventListener('click', () => openModal('Test operations', 'Open test analytics, pause new attempts, review issue logs or update publication status from the dedicated Test Operations screen.', '▤')));
  showToast('Admin control center is live.');
})();
