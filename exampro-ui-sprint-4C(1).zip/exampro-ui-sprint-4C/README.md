# ExamPro UI — Sprint 4C

Open `live-test.html` to preview the live exam interface.

## Sprint 4C additions

- Reliable deadline-based countdown that remains accurate after tab throttling or returning from another window
- Persistent session recovery for answers, review states, notes, language, timer, and per-question time
- Clear autosave states: Saving, Saved, Saved locally, and Synced
- Offline banner and automatic reconnection sync feedback
- Test Settings drawer accessible from the left navigation
- Dark, Light, and System appearance modes
- Small, Default, and Large question text sizes
- High-contrast and reduced-motion accessibility modes
- Optional Screen Wake Lock when supported by the browser
- Improved fullscreen state handling
- Five-minute and one-minute timer warnings
- Session reset control with two-step confirmation
- Existing Focus Mode, adaptive 1–100 palette, Notes, Calculator, keyboard shortcuts, and submission review preserved

## Keyboard shortcuts

- `1–4`: Select an answer
- `←` / `→`: Previous or next question
- `R`: Mark for review
- `C`: Clear response
- `F`: Toggle Focus Mode
- `N`: Open Notes
- `K`: Open Calculator
- `?` or `Ctrl + /`: Show shortcuts while in Focus Mode
- `Esc`: Close the active panel or exit Focus Mode
