const root=document.documentElement;
const byId=id=>document.getElementById(id);
const sidebar=byId('sidebar');
const commandModal=byId('commandModal');
const commandInput=byId('commandInput');
const toast=byId('toast');

function showToast(message){if(!toast)return;toast.textContent=message;toast.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>toast.classList.remove('show'),2600)}
function bind(id,event,handler){const el=byId(id);if(el)el.addEventListener(event,handler)}

root.dataset.theme=localStorage.getItem('exampro-theme')||'dark';
bind('menuBtn','click',()=>sidebar?.classList.toggle('open'));
bind('themeBtn','click',()=>{const next=root.dataset.theme==='dark'?'light':'dark';root.dataset.theme=next;localStorage.setItem('exampro-theme',next);showToast(`${next[0].toUpperCase()+next.slice(1)} theme enabled`)});
bind('continueBtn','click',()=>showToast('Live-test screen will be connected in the next sprint.'));

document.querySelectorAll('.segmented button').forEach(btn=>btn.addEventListener('click',e=>{e.currentTarget.parentElement.querySelectorAll('button').forEach(b=>b.classList.remove('active'));e.currentTarget.classList.add('active')}));
document.querySelectorAll('.exam-card .btn').forEach(btn=>btn.addEventListener('click',()=>showToast('Mock test selected.')));

function openCommand(){if(!commandModal)return;commandModal.classList.add('open');commandModal.setAttribute('aria-hidden','false');setTimeout(()=>commandInput?.focus(),50)}
function closeCommand(){if(!commandModal)return;commandModal.classList.remove('open');commandModal.setAttribute('aria-hidden','true')}
bind('searchInput','focus',openCommand);
commandModal?.addEventListener('click',e=>{if(e.target===commandModal)closeCommand()});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand()}if(e.key==='Escape')closeCommand()});

const counters=[...document.querySelectorAll('[data-count]')];
if(counters.length){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(!entry.isIntersecting)return;const el=entry.target,target=parseFloat(el.dataset.count),suffix=el.dataset.suffix||'';const duration=900,started=performance.now();function tick(now){const p=Math.min((now-started)/duration,1),value=target*(1-Math.pow(1-p,3));el.textContent=(Number.isInteger(target)?Math.round(value):value.toFixed(1))+suffix;if(p<1)requestAnimationFrame(tick)}requestAnimationFrame(tick);observer.unobserve(el)}),{threshold:.5});counters.forEach(c=>observer.observe(c))}

// Test catalog interactions
const catalog=byId('testCatalog');
if(catalog){
  const cards=[...catalog.querySelectorAll('.test-list-card')];
  const search=byId('catalogSearch'),type=byId('typeFilter'),difficulty=byId('difficultyFilter'),sort=byId('sortFilter'),count=byId('resultCount'),empty=byId('emptyState');
  let category='all',savedOnly=false;

  function applyFilters(){
    const term=(search?.value||'').trim().toLowerCase();
    const visible=cards.filter(card=>{
      const matchCategory=category==='all'||card.dataset.category===category;
      const matchType=!type||type.value==='all'||card.dataset.type===type.value;
      const matchDifficulty=!difficulty||difficulty.value==='all'||card.dataset.difficulty===difficulty.value;
      const matchText=!term||card.dataset.title.toLowerCase().includes(term)||card.textContent.toLowerCase().includes(term);
      const matchSaved=!savedOnly||card.querySelector('.bookmark-btn')?.classList.contains('saved');
      const show=matchCategory&&matchType&&matchDifficulty&&matchText&&matchSaved;
      card.hidden=!show;return show;
    });
    if(sort){const mode=sort.value;const sorted=[...visible].sort((a,b)=>mode==='rating'?+b.dataset.rating-+a.dataset.rating:mode==='newest'?(b.querySelector('.pill.new')?1:0)-(a.querySelector('.pill.new')?1:0):mode==='duration'?+a.dataset.duration-+b.dataset.duration:+b.dataset.popularity-+a.dataset.popularity);sorted.forEach(card=>catalog.appendChild(card))}
    if(count)count.textContent=`${visible.length} ${visible.length===1?'test':'tests'}`;
    empty?.classList.toggle('show',visible.length===0);
  }
  function resetFilters(){category='all';savedOnly=false;if(search)search.value='';if(type)type.value='all';if(difficulty)difficulty.value='all';if(sort)sort.value='popular';document.querySelectorAll('#examTabs button').forEach((b,i)=>b.classList.toggle('active',i===0));byId('savedFilterBtn')?.classList.remove('active');applyFilters()}

  document.querySelectorAll('#examTabs button').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('#examTabs button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');category=btn.dataset.category;applyFilters()}));
  [search,type,difficulty,sort].forEach(el=>el?.addEventListener(el===search?'input':'change',applyFilters));
  bind('clearFilters','click',resetFilters);bind('emptyReset','click',resetFilters);
  bind('savedFilterBtn','click',e=>{savedOnly=!savedOnly;e.currentTarget.classList.toggle('active',savedOnly);applyFilters();showToast(savedOnly?'Showing saved tests':'Showing all tests')});
  bind('gridViewBtn','click',()=>{catalog.classList.add('grid-mode');byId('gridViewBtn').classList.add('active');byId('listViewBtn').classList.remove('active')});
  bind('listViewBtn','click',()=>{catalog.classList.remove('grid-mode');byId('listViewBtn').classList.add('active');byId('gridViewBtn').classList.remove('active')});
  document.querySelectorAll('.bookmark-btn').forEach(btn=>btn.addEventListener('click',()=>{btn.classList.toggle('saved');btn.textContent=btn.classList.contains('saved')?'◆':'◇';showToast(btn.classList.contains('saved')?'Test saved':'Removed from saved tests');if(savedOnly)applyFilters()}));
  document.querySelectorAll('.start-test,.continue-test').forEach(btn=>btn.addEventListener('click',()=>{showToast('Opening test instructions…');setTimeout(()=>{window.location.href='instructions.html'},450)}));
  bind('dailyPracticeBtn','click',()=>showToast('Your personalized daily practice set is ready.'));
  applyFilters();
}

setTimeout(()=>showToast(document.body.dataset.page==='tests'?'248 mock tests are ready to explore.':'Welcome back, Amit. Your dashboard is ready.'),600);

// Test instructions interactions
if(document.body.dataset.page==='instructions'){
  const agree=byId('agreeCheck'),start=byId('startExamBtn'),overlay=byId('shortcutOverlay');
  agree?.addEventListener('change',()=>{start.disabled=!agree.checked;showToast(agree.checked?'You are ready to begin.':'Please accept the instructions to continue.')});
  document.querySelectorAll('.toggle').forEach(toggle=>toggle.addEventListener('click',()=>{toggle.classList.toggle('active');toggle.setAttribute('aria-pressed',toggle.classList.contains('active'));if(toggle.id==='contrastToggle')document.body.classList.toggle('high-contrast',toggle.classList.contains('active'));if(toggle.id==='fontToggle')document.body.classList.toggle('large-test-text',toggle.classList.contains('active'));if(toggle.id==='fullscreenToggle'&&toggle.classList.contains('active')&&document.documentElement.requestFullscreen){document.documentElement.requestFullscreen().catch(()=>{})}}));
  function openShortcuts(){overlay?.classList.add('open');overlay?.setAttribute('aria-hidden','false')}
  function closeShortcuts(){overlay?.classList.remove('open');overlay?.setAttribute('aria-hidden','true')}
  bind('shortcutDemoBtn','click',openShortcuts);bind('closeShortcutModal','click',closeShortcuts);bind('gotItBtn','click',closeShortcuts);overlay?.addEventListener('click',e=>{if(e.target===overlay)closeShortcuts()});
  bind('runChecksBtn','click',()=>{const checks=[...document.querySelectorAll('#systemChecks>div')];checks.forEach((item,i)=>{item.classList.add('running');item.querySelector('small').textContent='Checking…';setTimeout(()=>{item.classList.remove('running');item.querySelector('small').textContent=['Ready','Online','Optimized','Available'][i];if(i===checks.length-1)showToast('All system checks passed.')},500+i*260)});byId('readinessText').textContent='Checking';byId('readinessBar').style.width='28%';setTimeout(()=>{byId('readinessText').textContent='100%';byId('readinessBar').style.width='100%'},1400)});
  bind('startExamBtn','click',()=>{if(start.disabled)return;showToast('Opening the live test interface…');setTimeout(()=>{window.location.href='live-test.html'},650)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeShortcuts()});
  const browser=byId('browserStatus'),network=byId('networkStatus'),display=byId('displayStatus'),storage=byId('storageStatus');if(browser)browser.textContent=/Chrome|Firefox|Safari|Edg/.test(navigator.userAgent)?'Ready':'Review recommended';if(network)network.textContent=navigator.onLine?'Online':'Offline';if(display)display.textContent=`${window.innerWidth} × ${window.innerHeight}`;if(storage){try{localStorage.setItem('exampro-check','ok');localStorage.removeItem('exampro-check');storage.textContent='Available'}catch{storage.textContent='Limited'}}
}

// Sprint 4B/4C — Stateful exam player and power features
if(document.body.dataset.page==='live-test'){
  const options=[...document.querySelectorAll('.answer-option')];
  const palette=byId('paletteGrid');
  const drawer=byId('examDrawer');
  const backdrop=byId('drawerBackdrop');
  const submitModal=byId('submitModal');
  const focusHint=byId('focusModeHint');
  const focusShortcutsOverlay=byId('focusShortcutsOverlay');
  const STORAGE_KEY='exampro-live-session-v4b';
  const SETTINGS_KEY='exampro-live-preferences-v4c';
  const hadSavedSession=Boolean(localStorage.getItem(STORAGE_KEY));
  const TOTAL_QUESTIONS=100;
  const TOTAL_DURATION=60*60;
  const optionKeys=['A','B','C','D'];
  const sectionOrder=['english','reasoning','math','gk'];
  const sections={
    english:{label:'English',start:26,end:50},
    reasoning:{label:'Reasoning',start:1,end:25},
    math:{label:'Math',start:51,end:75},
    gk:{label:'GK',start:76,end:100}
  };
  const questionCopy={
    english:{
      en:{question:'Select the most appropriate synonym of the given word.',keyword:'PERSISTENT',options:['Temporary','Intermittent','Continual','Occasional']},
      hi:{question:'दिए गए शब्द का सबसे उपयुक्त समानार्थी शब्द चुनिए।',keyword:'PERSISTENT',options:['अस्थायी','रुक-रुक कर होने वाला','निरंतर','कभी-कभार होने वाला']}
    },
    reasoning:{
      en:{question:'Which number should replace the question mark in the series?',keyword:'3, 8, 15, 24, 35, ?',options:['46','48','50','52']},
      hi:{question:'श्रृंखला में प्रश्नवाचक चिह्न के स्थान पर कौन-सी संख्या आएगी?',keyword:'3, 8, 15, 24, 35, ?',options:['46','48','50','52']}
    },
    math:{
      en:{question:'Find the value of the following expression.',keyword:'35% of 240',options:['72','84','96','108']},
      hi:{question:'निम्नलिखित व्यंजक का मान ज्ञात कीजिए।',keyword:'240 का 35%',options:['72','84','96','108']}
    },
    gk:{
      en:{question:'Which Article of the Constitution of India guarantees equality before law?',keyword:'RIGHT TO EQUALITY',options:['Article 14','Article 19','Article 21','Article 32']},
      hi:{question:'भारतीय संविधान का कौन-सा अनुच्छेद कानून के समक्ष समानता की गारंटी देता है?',keyword:'समानता का अधिकार',options:['अनुच्छेद 14','अनुच्छेद 19','अनुच्छेद 21','अनुच्छेद 32']}
    }
  };

  const seededAnswered=[1,2,3,5,6,8,9,10,11,12,14,15,16,17,18,20,21,22,23,24,25,27,28,29,30,31,33,34,36,38,40,51,52,54,56,58,61,63,66,70,76,77,80,84,88,92];
  const seededReview=[4,7,13,19,26,35,39,55,68,79,95];
  const seededVisited=[...seededAnswered,...seededReview,32,37,41,42,53,57,60,64,69,78,82,90];
  const seedResponses={};
  seededAnswered.forEach((q,index)=>{seedResponses[q]=optionKeys[index%4]});

  function loadSession(){
    const fallback={current:42,remaining:38*60+22,responses:seedResponses,review:seededReview,visited:seededVisited,notes:{},questionTimes:{42:42},language:'en',savedAt:0,endsAt:0};
    try{
      const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||'null');
      return saved&&typeof saved==='object'?{...fallback,...saved}:fallback;
    }catch{return fallback}
  }
  function loadPreferences(){
    const fallback={theme:localStorage.getItem('exampro-theme')||'dark',fontSize:'default',highContrast:false,reduceMotion:false,wakeLock:false};
    try{
      const saved=JSON.parse(localStorage.getItem(SETTINGS_KEY)||'null');
      return saved&&typeof saved==='object'?{...fallback,...saved}:fallback;
    }catch{return fallback}
  }
  const session=loadSession();
  const preferences=loadPreferences();
  let current=Math.min(TOTAL_QUESTIONS,Math.max(1,Number(session.current)||42));
  let remaining=Math.max(0,Number(session.remaining)||38*60+22);
  let endsAt=Number(session.endsAt)||Date.now()+remaining*1000;
  if(Number(session.endsAt))remaining=Math.max(0,Math.ceil((endsAt-Date.now())/1000));
  let selected=null;
  let fontStep=preferences.fontSize==='large'?1:preferences.fontSize==='small'?-1:0;
  let activeSubject='english';
  let focusHintTimer;
  let saveTimer;
  let confirmArmed=false;
  let calcExpression='';
  let calcResult='0';
  let lastSavedAt=Number(session.savedAt)||0;
  let timerExpired=false;
  let fiveMinuteAlertShown=remaining<=300;
  let oneMinuteAlertShown=remaining<=60;
  let wakeLock=null;
  let resetSessionArmed=false;
  let hiddenAt=0;
  const responses=new Map(Object.entries(session.responses||{}).map(([q,a])=>[Number(q),a]));
  const review=new Set((session.review||[]).map(Number));
  const visited=new Set((session.visited||[]).map(Number));
  const notes={...(session.notes||{})};
  const questionTimes={...(session.questionTimes||{})};

  function resolvedTheme(mode=preferences.theme){
    if(mode!=='system')return mode;
    return window.matchMedia?.('(prefers-color-scheme: light)').matches?'light':'dark';
  }
  function persistPreferences(){
    try{
      localStorage.setItem(SETTINGS_KEY,JSON.stringify(preferences));
      localStorage.setItem('exampro-theme',resolvedTheme());
    }catch{}
  }
  function applyPreferences({announce=false}={}){
    root.dataset.theme=resolvedTheme();
    root.dataset.themeMode=preferences.theme;
    document.body.classList.toggle('font-small',preferences.fontSize==='small');
    document.body.classList.toggle('font-large',preferences.fontSize==='large');
    document.body.classList.toggle('high-contrast',Boolean(preferences.highContrast));
    document.body.classList.toggle('reduce-motion',Boolean(preferences.reduceMotion));
    fontStep=preferences.fontSize==='large'?1:preferences.fontSize==='small'?-1:0;
    byId('fontSizeBtn')?.setAttribute('aria-pressed',String(preferences.fontSize!=='default'));
    persistPreferences();
    if(announce)showToast('Test appearance updated.');
  }
  async function requestWakeLock(){
    if(!preferences.wakeLock||!('wakeLock' in navigator)||document.visibilityState!=='visible')return;
    try{
      wakeLock=await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release',()=>{wakeLock=null});
    }catch{
      preferences.wakeLock=false;
      persistPreferences();
      showToast('Screen wake lock is not available in this browser.');
    }
  }
  async function releaseWakeLock(){
    try{await wakeLock?.release()}catch{}
    wakeLock=null;
  }
  function updateNetworkState({announce=false,recovered=false}={}){
    const online=navigator.onLine;
    const status=byId('networkStatusText');
    const chip=byId('candidateChip');
    const banner=byId('networkBanner');
    if(status)status.innerHTML=`<i class="network-dot" aria-hidden="true"></i> ${online?'Online':'Offline'}`;
    chip?.classList.toggle('offline',!online);
    banner?.classList.toggle('show',!online);
    banner?.classList.toggle('recovered',Boolean(online&&recovered));
    if(!online){
      setSaveState('Saved locally','waiting for connection','offline');
      if(announce)showToast('Connection lost. Your work is still saved locally.');
    }else{
      persistSession();
      setSaveState('Synced',formatSaveAge(),'saved');
      if(recovered&&banner){
        if(byId('networkBannerTitle'))byId('networkBannerTitle').textContent='Connection restored';
        if(byId('networkBannerCopy'))byId('networkBannerCopy').textContent='Your latest answers and notes are synced.';
        banner.classList.add('show');
        setTimeout(()=>{
          banner.classList.remove('show','recovered');
          if(byId('networkBannerTitle'))byId('networkBannerTitle').textContent='You are offline';
          if(byId('networkBannerCopy'))byId('networkBannerCopy').textContent='Your answers are saved on this device and will sync when the connection returns.';
        },2800);
      }else if(announce)showToast('Connection restored. Changes synced.');
    }
  }
  function renderSettingsDrawer(){
    const title=byId('drawerTitle');
    const content=byId('drawerContent');
    if(!title||!content)return;
    title.textContent='Test Settings';
    if(byId('drawerEyebrow'))byId('drawerEyebrow').textContent='TEST CONTROLS';
    const wakeSupported='wakeLock' in navigator;
    content.innerHTML=`
      <div class="settings-panel">
        <section class="settings-section">
          <div class="settings-heading"><div><strong>Appearance</strong><small>Choose how the test interface looks.</small></div></div>
          <div class="settings-segment" role="group" aria-label="Theme">
            ${['dark','light','system'].map(mode=>`<button type="button" data-theme-mode="${mode}" class="${preferences.theme===mode?'active':''}">${mode[0].toUpperCase()+mode.slice(1)}</button>`).join('')}
          </div>
        </section>
        <section class="settings-section">
          <div class="settings-heading"><div><strong>Question text</strong><small>Adjust reading size without zooming the page.</small></div></div>
          <div class="settings-segment" role="group" aria-label="Question text size">
            ${['small','default','large'].map(size=>`<button type="button" data-font-size="${size}" class="${preferences.fontSize===size?'active':''}">${size[0].toUpperCase()+size.slice(1)}</button>`).join('')}
          </div>
        </section>
        <section class="settings-section settings-toggles">
          <button type="button" class="settings-toggle ${preferences.highContrast?'active':''}" data-setting-toggle="highContrast" aria-pressed="${Boolean(preferences.highContrast)}"><span><strong>High contrast</strong><small>Increase borders and status distinction.</small></span><i></i></button>
          <button type="button" class="settings-toggle ${preferences.reduceMotion?'active':''}" data-setting-toggle="reduceMotion" aria-pressed="${Boolean(preferences.reduceMotion)}"><span><strong>Reduce motion</strong><small>Limit animated transitions and effects.</small></span><i></i></button>
          <button type="button" class="settings-toggle ${preferences.wakeLock?'active':''}" data-setting-toggle="wakeLock" aria-pressed="${Boolean(preferences.wakeLock)}" ${wakeSupported?'':'disabled'}><span><strong>Keep screen awake</strong><small>${wakeSupported?'Prevent the display from sleeping during the test.':'Not supported by this browser.'}</small></span><i></i></button>
        </section>
        <section class="settings-section session-controls">
          <div class="settings-heading"><div><strong>Session data</strong><small>Your answers, notes and timer are saved on this device.</small></div></div>
          <button type="button" class="drawer-mini-btn danger reset-session-btn" id="resetSessionBtn">Reset saved session</button>
        </section>
      </div>`;
    content.querySelectorAll('[data-theme-mode]').forEach(button=>button.addEventListener('click',()=>{
      preferences.theme=button.dataset.themeMode;
      applyPreferences({announce:true});
      renderSettingsDrawer();
    }));
    content.querySelectorAll('[data-font-size]').forEach(button=>button.addEventListener('click',()=>{
      preferences.fontSize=button.dataset.fontSize;
      applyPreferences({announce:true});
      renderSettingsDrawer();
    }));
    content.querySelectorAll('[data-setting-toggle]').forEach(button=>button.addEventListener('click',async()=>{
      const key=button.dataset.settingToggle;
      preferences[key]=!preferences[key];
      applyPreferences({announce:true});
      if(key==='wakeLock')preferences.wakeLock?await requestWakeLock():await releaseWakeLock();
      renderSettingsDrawer();
    }));
    bind('resetSessionBtn','click',()=>{
      const button=byId('resetSessionBtn');
      if(!resetSessionArmed){
        resetSessionArmed=true;
        button.textContent='Click again to reset';
        setTimeout(()=>{resetSessionArmed=false;if(byId('resetSessionBtn'))byId('resetSessionBtn').textContent='Reset saved session'},3500);
        return;
      }
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    });
  }
  applyPreferences();

  function subjectForQuestion(q){
    return sectionOrder.find(id=>q>=sections[id].start&&q<=sections[id].end)||'english';
  }
  function rangeForSubject(id){
    const section=sections[id]||sections.english;
    return Array.from({length:section.end-section.start+1},(_,index)=>section.start+index);
  }
  function statusFor(q){
    if(review.has(q))return 'review';
    if(responses.has(q))return 'answered';
    if(visited.has(q))return 'unanswered';
    return 'unvisited';
  }
  function statusLabel(q){
    const status=statusFor(q);
    if(status==='review'&&responses.has(q))return 'Answered and marked for review';
    return {answered:'Answered',review:'Marked for review',unanswered:'Not answered',unvisited:'Not visited'}[status];
  }
  function serializeSession(){
    return {
      current,
      remaining,
      endsAt,
      responses:Object.fromEntries(responses),
      review:[...review],
      visited:[...visited],
      notes,
      questionTimes,
      language:byId('languageSelect')?.value||'en',
      savedAt:Date.now()
    };
  }
  function persistSession(){
    lastSavedAt=Date.now();
    try{localStorage.setItem(STORAGE_KEY,JSON.stringify(serializeSession()))}catch{}
  }
  function formatSaveAge(){
    if(!lastSavedAt)return 'not saved yet';
    const seconds=Math.max(0,Math.floor((Date.now()-lastSavedAt)/1000));
    if(seconds<5)return 'just now';
    if(seconds<60)return `${seconds}s ago`;
    const minutes=Math.floor(seconds/60);
    return `${minutes}m ago`;
  }
  function setSaveState(label,detail,mode='saved'){
    const state=byId('saveState');
    if(!state)return;
    state.dataset.state=mode;
    if(byId('saveStateLabel'))byId('saveStateLabel').textContent=label;
    if(byId('saveStateTime'))byId('saveStateTime').textContent=detail;
    if(byId('saveStateIcon'))byId('saveStateIcon').textContent=mode==='saving'?'↻':mode==='offline'?'●':'✓';
  }
  function savePulse(silent=false){
    clearTimeout(saveTimer);
    if(!silent)setSaveState('Saving…','please wait','saving');
    saveTimer=setTimeout(()=>{
      persistSession();
      if(navigator.onLine)setSaveState('Saved',formatSaveAge(),'saved');
      else setSaveState('Saved locally','waiting for connection','offline');
    },silent?0:320);
  }
  function updateTimeSpent(){
    const spent=Math.max(0,Number(questionTimes[current])||0);
    const minutes=String(Math.floor(spent/60)).padStart(2,'0');
    const seconds=String(spent%60).padStart(2,'0');
    if(byId('timeSpent'))byId('timeSpent').textContent=`${minutes}:${seconds}`;
  }
  function updateToolStates(){
    const note=String(notes[current]||'').trim();
    byId('notesBtn')?.classList.toggle('has-note',Boolean(note));
  }
  function updateReviewButton(){
    const button=byId('reviewBtn');
    if(!button)return;
    const active=review.has(current);
    button.classList.toggle('active',active);
    button.setAttribute('aria-pressed',String(active));
    const label=button.querySelector('span');
    if(label)label.textContent=active?'Remove Review':'Mark for Review';
  }
  function updateSectionProgress(){
    sectionOrder.forEach(id=>{
      const range=rangeForSubject(id);
      const attempted=range.filter(q=>responses.has(q)).length;
      const target=byId(`${id}Progress`);
      if(target)target.textContent=`${attempted}/25`;
    });
  }
  function renderSubjectTabs(){
    document.querySelectorAll('#subjectTabs button').forEach(button=>{
      const active=button.dataset.subject===activeSubject;
      button.classList.toggle('active',active);
      button.setAttribute('aria-pressed',String(active));
    });
    updateSectionProgress();
  }
  let paletteFitFrame=0;
  function fitPaletteGrid(){
    if(!palette)return;
    cancelAnimationFrame(paletteFitFrame);
    paletteFitFrame=requestAnimationFrame(()=>{
      const count=palette.children.length;
      if(!count)return;

      const width=palette.clientWidth;
      const height=palette.clientHeight;
      if(width<80||height<80)return;

      const mobile=window.matchMedia('(max-width:820px)').matches;
      const minColumns=mobile?4:Math.max(4,Math.min(6,Math.ceil(Math.sqrt(count)/2)));
      const maxColumns=Math.min(count,mobile?7:14);
      const maxChip=mobile?44:48;
      let best=null;

      for(let columns=minColumns;columns<=maxColumns;columns++){
        const rows=Math.ceil(count/columns);
        for(const gap of mobile?[7,6,5]:[8,7,6,5]){
          const sizeByWidth=(width-gap*(columns-1))/columns;
          const sizeByHeight=(height-gap*(rows-1))/rows;
          const rawSize=Math.min(sizeByWidth,sizeByHeight);
          if(rawSize<=0)continue;
          const chipSize=Math.min(maxChip,rawSize);
          const usedWidth=columns*chipSize+(columns-1)*gap;
          const usedHeight=rows*chipSize+(rows-1)*gap;
          const widthFill=Math.min(1,usedWidth/width);
          const heightFill=Math.min(1,usedHeight/height);
          const fillScore=(widthFill+heightFill)/2;
          const score=chipSize*100+fillScore*10-gap*.01;
          if(!best||score>best.score)best={columns,rows,gap,chipSize,score};
        }
      }

      if(!best)return;
      const chip=Math.max(mobile?30:24,Math.floor(best.chipSize));
      palette.style.setProperty('--palette-columns',best.columns);
      palette.style.setProperty('--palette-chip-size',`${chip}px`);
      palette.style.setProperty('--palette-gap',`${best.gap}px`);
      palette.classList.toggle('palette-dense',chip<32);
      palette.classList.toggle('palette-spacious',chip>=40);
      palette.dataset.layout=`${best.columns} columns × ${best.rows} rows`;
    });
  }
  function renderPalette(){
    if(!palette)return;
    palette.innerHTML='';
    Array.from({length:TOTAL_QUESTIONS},(_,index)=>index+1).forEach(q=>{
      const button=document.createElement('button');
      const status=statusFor(q);
      button.type='button';
      button.className=`palette-question ${status}`;
      if(q===current)button.classList.add('current');
      if(review.has(q)&&responses.has(q))button.classList.add('has-answer');
      if(String(notes[q]||'').trim())button.classList.add('has-note');
      button.textContent=q;
      button.dataset.question=q;
      button.setAttribute('aria-label',`Question ${q}: ${statusLabel(q)}${String(notes[q]||'').trim()?'; note added':''}`);
      button.title=`Question ${q} · ${statusLabel(q)}`;
      button.addEventListener('click',()=>goToQuestion(q));
      palette.appendChild(button);
    });
    updateSectionProgress();
    fitPaletteGrid();
  }
  function renderQuestionCopy(){
    const language=byId('languageSelect')?.value||'en';
    const subject=subjectForQuestion(current);
    const copy=questionCopy[subject]?.[language]||questionCopy[subject]?.en||questionCopy.english.en;
    if(byId('questionText'))byId('questionText').textContent=copy.question;
    if(byId('questionKeyword'))byId('questionKeyword').textContent=copy.keyword;
    options.forEach((option,index)=>{
      const label=option.querySelector('.option-copy');
      if(label)label.textContent=copy.options[index];
    });
  }
  function restoreResponse(){
    selected=responses.get(current)||null;
    options.forEach(option=>{
      const active=option.dataset.option===selected;
      option.classList.toggle('selected',active);
      option.setAttribute('aria-checked',String(active));
    });
  }
  function goToQuestion(number,{quiet=false}={}){
    current=Math.min(TOTAL_QUESTIONS,Math.max(1,Number(number)||1));
    visited.add(current);
    if(byId('questionNumber'))byId('questionNumber').textContent=current;
    if(byId('questionPromptNumber'))byId('questionPromptNumber').textContent=current;
    if(byId('examProgress'))byId('examProgress').style.width=`${current}%`;
    renderQuestionCopy();
    restoreResponse();
    renderPalette();
    updateReviewButton();
    updateToolStates();
    updateTimeSpent();
    savePulse(quiet);
    if(innerWidth<=820)byId('examSidebar')?.classList.remove('open');
  }
  function selectOption(option){
    if(!option)return;
    selected=option.dataset.option;
    responses.set(current,selected);
    visited.add(current);
    restoreResponse();
    renderPalette();
    updateSectionProgress();
    savePulse();
  }

  options.forEach(option=>option.addEventListener('click',()=>selectOption(option)));
  bind('previousBtn','click',()=>goToQuestion(current-1));
  bind('saveNextBtn','click',()=>goToQuestion(current+1));
  bind('clearBtn','click',()=>{
    responses.delete(current);
    selected=null;
    visited.add(current);
    restoreResponse();
    renderPalette();
    updateSectionProgress();
    savePulse();
    showToast('Response cleared.');
  });
  bind('reviewBtn','click',()=>{
    if(review.has(current)){
      review.delete(current);
      showToast('Review mark removed.');
    }else{
      review.add(current);
      visited.add(current);
      showToast('Question marked for review.');
    }
    updateReviewButton();
    renderPalette();
    savePulse();
  });
  bind('reportBtn','click',()=>showToast('Question flagged for review by the content team.'));

  const languageSelect=byId('languageSelect');
  if(languageSelect&&['en','hi'].includes(session.language))languageSelect.value=session.language;
  languageSelect?.addEventListener('change',()=>{
    renderQuestionCopy();
    savePulse();
    showToast(languageSelect.value==='hi'?'हिंदी भाषा चुनी गई।':'English language selected.');
  });

  function updateExamTimer(){
    remaining=Math.max(0,Math.ceil((endsAt-Date.now())/1000));
    const minutes=Math.floor(remaining/60);
    const seconds=remaining%60;
    if(byId('timerText'))byId('timerText').textContent=`${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;
    const timer=byId('examTimer');
    timer?.classList.toggle('warning',remaining<=300&&remaining>60);
    timer?.classList.toggle('critical',remaining<=60);
    const progress=Math.max(0,Math.min(100,remaining/TOTAL_DURATION*100));
    const ring=byId('timerRing')?.parentElement;
    if(ring)ring.style.background=`conic-gradient(${remaining<=60?'#ff5577':remaining<=300?'#f4b347':'#7c69ff'} ${progress}%,rgba(255,255,255,.08) 0)`;
    if(remaining<=300&&!fiveMinuteAlertShown){fiveMinuteAlertShown=true;showToast('5 minutes remaining. Review your unanswered questions.')}
    if(remaining<=60&&!oneMinuteAlertShown){oneMinuteAlertShown=true;showToast('1 minute remaining. Submit when ready.')}
    if(!remaining&&!timerExpired){timerExpired=true;clearInterval(examTimerInterval);openSubmit()}
  }
  updateExamTimer();
  const examTimerInterval=setInterval(()=>{
    updateExamTimer();
    if(remaining%10===0)savePulse(true);
  },1000);
  const questionTimeInterval=setInterval(()=>{
    questionTimes[current]=(Number(questionTimes[current])||0)+1;
    updateTimeSpent();
    if(questionTimes[current]%10===0)savePulse(true);
  },1000);

  function showFocusHint(){
    if(!focusHint)return;
    clearTimeout(focusHintTimer);
    focusHint.classList.add('show');
    focusHintTimer=setTimeout(()=>focusHint.classList.remove('show'),4000);
  }
  function hideFocusHint(){clearTimeout(focusHintTimer);focusHint?.classList.remove('show')}
  function openFocusShortcuts(){
    if(!document.body.classList.contains('focus-mode')||!focusShortcutsOverlay)return;
    hideFocusHint();
    focusShortcutsOverlay.classList.add('open');
    focusShortcutsOverlay.setAttribute('aria-hidden','false');
    setTimeout(()=>byId('focusShortcutsCloseBtn')?.focus(),30);
  }
  function closeFocusShortcuts(){
    focusShortcutsOverlay?.classList.remove('open');
    focusShortcutsOverlay?.setAttribute('aria-hidden','true');
  }
  bind('focusShortcutsCloseBtn','click',closeFocusShortcuts);
  focusShortcutsOverlay?.addEventListener('click',event=>{if(event.target===focusShortcutsOverlay)closeFocusShortcuts()});
  bind('focusBtn','click',()=>{
    const enabled=document.body.classList.toggle('focus-mode');
    const button=byId('focusBtn');
    button?.setAttribute('aria-pressed',String(enabled));
    button?.setAttribute('aria-label',enabled?'Exit focus mode':'Enter focus mode');
    if(enabled){showFocusHint();showToast('Focus mode enabled.')}
    else{hideFocusHint();closeFocusShortcuts();showToast('Focus mode disabled.')}
  });
  bind('fontSizeBtn','click',()=>{
    const sizes=['default','large','small'];
    const currentIndex=Math.max(0,sizes.indexOf(preferences.fontSize));
    preferences.fontSize=sizes[(currentIndex+1)%sizes.length];
    applyPreferences();
    showToast(`${preferences.fontSize[0].toUpperCase()+preferences.fontSize.slice(1)} question text enabled.`);
  });
  bind('fullscreenBtn','click',async()=>{
    try{
      if(!document.fullscreenElement)await document.documentElement.requestFullscreen?.();
      else await document.exitFullscreen?.();
    }catch{showToast('Fullscreen could not be started in this browser.')}
  });
  document.addEventListener('fullscreenchange',()=>{
    const active=Boolean(document.fullscreenElement);
    const button=byId('fullscreenBtn');
    button?.classList.toggle('active',active);
    button?.setAttribute('aria-pressed',String(active));
    button?.setAttribute('aria-label',active?'Exit fullscreen':'Enter fullscreen');
    button?.setAttribute('title',active?'Exit fullscreen':'Fullscreen');
    if(active&&preferences.wakeLock)requestWakeLock();
  });
  bind('paletteMobileBtn','click',()=>byId('examSidebar')?.classList.add('open'));
  bind('paletteCloseBtn','click',()=>byId('examSidebar')?.classList.remove('open'));

  function noteText(){return String(notes[current]||'')}
  function renderNotesDrawer(){
    const title=byId('drawerTitle');
    const content=byId('drawerContent');
    if(!title||!content)return;
    title.textContent=`Question ${current} Notes`;
    if(byId('drawerEyebrow'))byId('drawerEyebrow').textContent='QUICK TOOL';
    content.innerHTML=`
      <div class="drawer-context"><span>${sections[subjectForQuestion(current)].label} section</span><strong>Question ${current} of ${TOTAL_QUESTIONS}</strong></div>
      <div class="drawer-note">
        <textarea id="questionNoteInput" maxlength="1000" placeholder="Write a private note for this question…"></textarea>
        <div class="note-meta"><span id="noteCharacterCount">0 / 1000</span><span class="note-saved" id="noteSavedState">Saved automatically</span></div>
        <div class="drawer-footer-actions"><button class="drawer-mini-btn danger" id="clearNoteBtn">Clear note</button><button class="drawer-mini-btn primary" id="doneNoteBtn">Done</button></div>
      </div>`;
    const input=byId('questionNoteInput');
    const count=byId('noteCharacterCount');
    input.value=noteText();
    count.textContent=`${input.value.length} / 1000`;
    input.addEventListener('input',()=>{
      notes[current]=input.value;
      count.textContent=`${input.value.length} / 1000`;
      byId('noteSavedState').textContent='Saving…';
      updateToolStates();
      renderPalette();
      savePulse();
      setTimeout(()=>{if(byId('noteSavedState'))byId('noteSavedState').textContent='Saved automatically'},430);
    });
    bind('clearNoteBtn','click',()=>{
      input.value='';
      notes[current]='';
      count.textContent='0 / 1000';
      updateToolStates();
      renderPalette();
      savePulse();
      showToast('Question note cleared.');
    });
    bind('doneNoteBtn','click',closeDrawer);
    setTimeout(()=>input.focus(),60);
  }
  function formatCalculatorValue(value){
    const text=String(value);
    return text.length>15?Number(value).toExponential(8):text;
  }
  function updateCalculator(){
    const expression=byId('calculatorExpression');
    const display=byId('calculatorDisplay');
    if(expression)expression.textContent=calcExpression||'Ready';
    if(display)display.textContent=calcResult;
  }
  function evaluateCalculator(){
    if(!calcExpression)return;
    const normalized=calcExpression
      .replaceAll('×','*')
      .replaceAll('÷','/')
      .replaceAll('−','-')
      .replace(/(\d+(?:\.\d+)?)%/g,'($1/100)');
    if(!/^[0-9+\-*/().\s]+$/.test(normalized)){calcResult='Error';return updateCalculator()}
    try{
      const value=Function(`"use strict";return (${normalized})`)();
      if(!Number.isFinite(value))throw new Error('Invalid result');
      calcResult=formatCalculatorValue(Math.round((value+Number.EPSILON)*1e10)/1e10);
    }catch{calcResult='Error'}
    updateCalculator();
  }
  function handleCalculatorInput(value){
    if(value==='C'){calcExpression='';calcResult='0'}
    else if(value==='⌫'){calcExpression=calcExpression.slice(0,-1);calcResult=calcExpression||'0'}
    else if(value==='='){evaluateCalculator();return}
    else{
      if(calcResult==='Error'){calcExpression='';calcResult='0'}
      calcExpression+=value;
      calcResult=calcExpression;
    }
    updateCalculator();
  }
  function renderCalculatorDrawer(){
    const title=byId('drawerTitle');
    const content=byId('drawerContent');
    if(!title||!content)return;
    title.textContent='Calculator';
    if(byId('drawerEyebrow'))byId('drawerEyebrow').textContent='QUICK TOOL';
    const keys=['C','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','0','.','(',')','='];
    content.innerHTML=`
      <div class="calculator-shell">
        <div class="drawer-context"><span>Quick calculation tool</span><strong>Keyboard enabled</strong></div>
        <div class="calculator-display-wrap"><div class="calculator-expression" id="calculatorExpression">Ready</div><div class="calculator-display" id="calculatorDisplay">0</div></div>
        <div class="calculator-grid">${keys.map(key=>`<button type="button" data-calc-key="${key}" class="${['÷','×','−','+','%'].includes(key)?'operator ':''}${['C','⌫'].includes(key)?'utility ':''}${key==='='?'equals':''}">${key}</button>`).join('')}</div>
        <div class="calculator-keyboard-hint">Use number keys, operators, Enter and Backspace.</div>
      </div>`;
    content.querySelectorAll('[data-calc-key]').forEach(button=>button.addEventListener('click',()=>handleCalculatorInput(button.dataset.calcKey)));
    updateCalculator();
  }
  function openDrawer(type){
    if(!drawer||!backdrop)return;
    drawer.dataset.type=type;
    drawer.classList.add('open');
    backdrop.classList.add('open');
    drawer.setAttribute('aria-hidden','false');
    if(type==='notes')renderNotesDrawer();
    if(type==='calculator')renderCalculatorDrawer();
    if(type==='settings')renderSettingsDrawer();
  }
  function closeDrawer(){
    if(!drawer||!backdrop)return;
    drawer.classList.remove('open');
    backdrop.classList.remove('open');
    drawer.setAttribute('aria-hidden','true');
    drawer.dataset.type='';
  }
  bind('notesBtn','click',()=>openDrawer('notes'));
  bind('calculatorBtn','click',()=>openDrawer('calculator'));
  bind('examSettingsBtn','click',event=>{event.preventDefault();openDrawer('settings')});
  bind('drawerCloseBtn','click',closeDrawer);
  backdrop?.addEventListener('click',closeDrawer);

  function countStatuses(){
    const counts={answered:0,review:0,unanswered:0,unvisited:0};
    for(let q=1;q<=TOTAL_QUESTIONS;q++)counts[statusFor(q)]++;
    return counts;
  }
  function updateSubmitSummary(){
    const counts=countStatuses();
    if(byId('submitAnswered'))byId('submitAnswered').textContent=counts.answered;
    if(byId('submitReview'))byId('submitReview').textContent=counts.review;
    if(byId('submitUnanswered'))byId('submitUnanswered').textContent=counts.unanswered;
    if(byId('submitUnvisited'))byId('submitUnvisited').textContent=counts.unvisited;
    const summary=byId('submitSummaryText');
    if(summary)summary.textContent=counts.unanswered||counts.unvisited||counts.review?'You still have questions that may need attention. Select a status to jump to it.':'Every question has been answered and cleared from review.';
    const sectionSummary=byId('submitSectionSummary');
    if(sectionSummary){
      sectionSummary.innerHTML=sectionOrder.map(id=>{
        const range=rangeForSubject(id);
        const answered=range.filter(q=>responses.has(q)).length;
        const percent=Math.round(answered/range.length*100);
        return `<div class="submit-section-row"><span>${sections[id].label}</span><i><b style="width:${percent}%"></b></i><small>${answered}/25</small></div>`;
      }).join('');
    }
  }
  function openSubmit(){
    if(!submitModal)return;
    confirmArmed=false;
    const button=byId('confirmSubmitBtn');
    if(button)button.textContent='Submit Test';
    updateSubmitSummary();
    submitModal.classList.add('open');
    submitModal.setAttribute('aria-hidden','false');
  }
  function closeSubmit(){
    submitModal?.classList.remove('open');
    submitModal?.setAttribute('aria-hidden','true');
    confirmArmed=false;
  }
  bind('submitTestBtn','click',openSubmit);
  bind('submitCloseBtn','click',closeSubmit);
  bind('continueTestBtn','click',closeSubmit);
  document.querySelectorAll('[data-jump-status]').forEach(button=>button.addEventListener('click',()=>{
    const status=button.dataset.jumpStatus;
    const target=Array.from({length:TOTAL_QUESTIONS},(_,index)=>index+1).find(q=>statusFor(q)===status);
    if(!target){showToast(`No ${status.replace('unanswered','not answered').replace('unvisited','not visited')} questions.`);return}
    closeSubmit();
    goToQuestion(target);
  }));
  bind('confirmSubmitBtn','click',()=>{
    if(!confirmArmed){
      confirmArmed=true;
      byId('confirmSubmitBtn').textContent='Confirm Submission';
      if(byId('submitSummaryText'))byId('submitSummaryText').textContent='This will end the test. Click Confirm Submission to continue.';
      return;
    }
    persistSession();
    closeSubmit();
    showToast('Test submitted. Results experience arrives in Sprint 5.');
  });

  function drawerIsOpen(){return drawer?.classList.contains('open')}
  function handleCalculatorKeyboard(event){
    if(drawer?.dataset.type!=='calculator')return false;
    const map={'/':'÷','*':'×','-':'−','+':'+','%':'%','(':'(',')':')','.':'.'};
    if(/^\d$/.test(event.key)){handleCalculatorInput(event.key);return true}
    if(map[event.key]){handleCalculatorInput(map[event.key]);return true}
    if(event.key==='Enter'||event.key==='='){handleCalculatorInput('=');return true}
    if(event.key==='Backspace'){handleCalculatorInput('⌫');return true}
    if(event.key==='Delete'){handleCalculatorInput('C');return true}
    return false;
  }
  document.addEventListener('keydown',event=>{
    const tag=document.activeElement?.tagName||'';
    const isTyping=['TEXTAREA','INPUT','SELECT'].includes(tag)||document.activeElement?.isContentEditable;
    const shortcutsOpen=focusShortcutsOverlay?.classList.contains('open');
    const shortcutHelp=event.key==='?'||((event.ctrlKey||event.metaKey)&&event.key==='/');

    if(event.key==='Escape'){
      if(shortcutsOpen){closeFocusShortcuts();return}
      if(drawerIsOpen()){closeDrawer();return}
      if(submitModal?.classList.contains('open')){closeSubmit();return}
      if(byId('examSidebar')?.classList.contains('open')){byId('examSidebar').classList.remove('open');return}
      if(document.body.classList.contains('focus-mode')){byId('focusBtn')?.click();return}
    }
    if(drawerIsOpen()&&drawer?.dataset.type==='calculator'&&!isTyping){
      if(handleCalculatorKeyboard(event)){event.preventDefault();return}
    }
    if(shortcutHelp&&document.body.classList.contains('focus-mode')&&!isTyping){
      event.preventDefault();
      shortcutsOpen?closeFocusShortcuts():openFocusShortcuts();
      return;
    }
    if(shortcutsOpen||isTyping)return;
    if(['1','2','3','4'].includes(event.key))selectOption(options[Number(event.key)-1]);
    if(event.key==='ArrowLeft')goToQuestion(current-1);
    if(event.key==='ArrowRight')goToQuestion(current+1);
    if(event.key.toLowerCase()==='r')byId('reviewBtn')?.click();
    if(event.key.toLowerCase()==='c')byId('clearBtn')?.click();
    if(event.key.toLowerCase()==='f')byId('focusBtn')?.click();
    if(event.key.toLowerCase()==='n')openDrawer('notes');
    if(event.key.toLowerCase()==='k')openDrawer('calculator');
  });

  const paletteResizeObserver='ResizeObserver' in window?new ResizeObserver(fitPaletteGrid):null;
  paletteResizeObserver?.observe(palette);
  window.addEventListener('resize',fitPaletteGrid,{passive:true});

  window.addEventListener('offline',()=>updateNetworkState({announce:true}));
  window.addEventListener('online',()=>updateNetworkState({announce:true,recovered:true}));
  window.matchMedia?.('(prefers-color-scheme: light)').addEventListener?.('change',()=>{
    if(preferences.theme==='system')applyPreferences();
  });
  document.addEventListener('visibilitychange',()=>{
    if(document.visibilityState==='hidden'){
      hiddenAt=Date.now();
      persistSession();
      return;
    }
    updateExamTimer();
    if(preferences.wakeLock)requestWakeLock();
    if(hiddenAt&&Date.now()-hiddenAt>15000)showToast('Welcome back. The exam timer continued while you were away.');
    hiddenAt=0;
  });
  const saveAgeInterval=setInterval(()=>{
    if(navigator.onLine&&byId('saveState')?.dataset.state!=='saving')setSaveState('Saved',formatSaveAge(),'saved');
  },5000);
  window.addEventListener('pagehide',()=>{persistSession();clearInterval(saveAgeInterval)});

  visited.add(current);
  goToQuestion(current,{quiet:true});
  updateNetworkState();
  if(preferences.wakeLock)requestWakeLock();
  setTimeout(()=>{
    if(hadSavedSession&&session.savedAt){
      const restoredAt=new Date(Number(session.savedAt));
      const time=restoredAt.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
      showToast(`Session restored from ${time}.`);
    }else showToast('Sprint 4C loaded. Session protection and accessibility controls are active.');
  },500);
  window.addEventListener('beforeunload',persistSession);
}
